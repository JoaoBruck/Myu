# MYU — Outdoor Engine Lab v2

Foco desta build: fazer a protagonista **existir fisicamente na rua**, sem cafeteria.

## Alterações
- prédio agora possui hitboxes estáticas próprias em Matter Physics;
- todos os foreground props principais possuem contraparte física;
- velocidade reduzida de `145` para `92`;
- aceleração e desaceleração suavizadas;
- sprite aumentado para a escala oficial provisória da rua (`0.62–0.68`);
- hitbox do jogador continua concentrada nos pés (`34×18`);
- reflexo discreto da protagonista no piso molhado;
- pequenas ondulações/respingos aparecem nos passos;
- sombra e reflexo variam com a proximidade da iluminação dinâmica;
- depth sorting por Y preservado;
- debug mostra prédio em azul, props em vermelho e limite caminhável em verde.

## Debug
Abra com `?debug=1` para visualizar colisões.

## Testes
`test_report.txt` registra 5 testes automáticos. Todos devem estar `PASS` antes da publicação.
