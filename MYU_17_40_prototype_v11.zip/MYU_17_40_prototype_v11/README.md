# MYU — 17:40 v11

Ajustes aplicados nesta versão local:
- sprite da protagonista mais pixelado e coerente com o cenário;
- sombra sob a personagem em atlas próprio;
- câmera um pouco mais afastada;
- movimento suavizado;
- colisões reforçadas no exterior e no interior para evitar atravessar móveis, porta, balcão, placas e áreas fora da calçada;
- spawn de transição revisado;
- cache/service worker atualizado para v11.

Observação: esta pasta está pronta para teste local/publicação manual.
