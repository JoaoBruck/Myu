const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha: false });
ctx.imageSmoothingEnabled = false;

const qs = new URLSearchParams(location.search);
const DEBUG = qs.get('debug') === '1';
const assets = {};
const input = { x: 0, y: 0 };
const keys = {};
let world;
let bg, atlas, shadowAtlas;
let last = 0;
let dpr = 1;
let viewW = 0, viewH = 0;
let rain = [];
let ripples = [];
let rippleClock = 0;

const player = {
  x: 0, y: 0,
  vx: 0, vy: 0,
  dir: 'front', moving: false,
  anim: 0, idle: 0
};
const camera = { x: 0, y: 0, zoom: 1 };

const WALK = [0, 1, 2, 3, 2, 1];
const ROW = { front: 0, left: 1, right: 2, back: 3 };
const FW = 184, FH = 316;

async function loadImage(src) {
  const im = new Image();
  im.decoding = 'async';
  await new Promise((resolve, reject) => {
    im.onload = resolve;
    im.onerror = reject;
    im.src = src;
  });
  return im;
}

async function boot() {
  world = await fetch('data/world.json?v=3', { cache: 'no-store' }).then(r => {
    if (!r.ok) throw new Error('world.json');
    return r.json();
  });
  [bg, atlas, shadowAtlas] = await Promise.all([
    loadImage('assets/backgrounds/exterior.webp?v=3'),
    loadImage('assets/sprites/witch_walk_atlas.webp?v=3'),
    loadImage('assets/sprites/shadow_atlas.png?v=3')
  ]);

  player.x = world.player.spawn.x;
  player.y = world.player.spawn.y;
  player.dir = world.player.spawn.dir || 'front';
  camera.x = player.x;
  camera.y = player.y;

  makeRain();
  resize();
  requestAnimationFrame(loop);
}

function resize() {
  dpr = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
  viewW = window.innerWidth;
  viewH = window.innerHeight;
  canvas.width = Math.floor(viewW * dpr);
  canvas.height = Math.floor(viewH * dpr);
  canvas.style.width = viewW + 'px';
  canvas.style.height = viewH + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.imageSmoothingEnabled = false;
  if (bg) {
    camera.zoom = Math.max(viewW / bg.width, viewH / bg.height);
  }
}
addEventListener('resize', resize);

function makeRain() {
  rain = Array.from({ length: 120 }, (_, i) => ({
    x: (i * 79) % 1500,
    y: (i * 137) % 1120,
    speed: 310 + (i % 7) * 19,
    len: 5 + (i % 5),
    drift: 42 + (i % 4) * 4
  }));
}

function pointInPolygon(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i][0], yi = pts[i][1];
    const xj = pts[j][0], yj = pts[j][1];
    const intersect = ((yi > y) !== (yj > y)) &&
      (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-9) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function pointHitsShape(x, y, shape, extra = 0) {
  if (shape.type === 'rect') {
    return x >= shape.x - extra && x <= shape.x + shape.w + extra &&
           y >= shape.y - extra && y <= shape.y + shape.h + extra;
  }
  if (shape.type === 'circle') {
    const dx = x - shape.x, dy = y - shape.y;
    const r = shape.r + extra;
    return dx * dx + dy * dy <= r * r;
  }
  if (shape.type === 'polygon') {
    return pointInPolygon(x, y, shape.points);
  }
  return false;
}

function isWalkable(x, y) {
  const r = world.player.footRadius;
  const probes = [
    [0,0], [r,0], [-r,0], [0,r*0.7], [0,-r*0.7],
    [r*0.7,r*0.5], [-r*0.7,r*0.5], [r*0.7,-r*0.5], [-r*0.7,-r*0.5]
  ];

  for (const [ox, oy] of probes) {
    const px = x + ox, py = y + oy;
    if (!pointInPolygon(px, py, world.walkPolygon)) return false;
    for (const shape of world.buildingHitboxes) {
      if (pointHitsShape(px, py, shape, 0)) return false;
    }
    for (const shape of world.propHitboxes) {
      if (pointHitsShape(px, py, shape, 0)) return false;
    }
  }
  return true;
}

function moveWithCollision(dx, dy) {
  if (dx !== 0) {
    const nx = player.x + dx;
    if (isWalkable(nx, player.y)) player.x = nx;
    else player.vx = 0;
  }
  if (dy !== 0) {
    const ny = player.y + dy;
    if (isWalkable(player.x, ny)) player.y = ny;
    else player.vy = 0;
  }
}

addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  keys[k] = true;
  if (['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k)) e.preventDefault();
});
addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);

const stickZone = document.getElementById('stickZone');
const stickBase = document.getElementById('stickBase');
const knob = document.getElementById('stickKnob');
let dragging = false, pointerId = null;

function setStick(clientX, clientY) {
  const rect = stickBase.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const radius = rect.width * 0.34;
  let dx = clientX - cx, dy = clientY - cy;
  const mag = Math.hypot(dx, dy) || 1;
  const clamped = Math.min(radius, mag);
  dx = dx / mag * clamped;
  dy = dy / mag * clamped;
  input.x = dx / radius;
  input.y = dy / radius;
  knob.style.transform = `translate(${dx}px, ${dy}px)`;
}
function clearStick() {
  dragging = false;
  pointerId = null;
  input.x = input.y = 0;
  knob.style.transform = 'translate(0,0)';
}
stickZone.addEventListener('pointerdown', e => {
  dragging = true; pointerId = e.pointerId;
  stickZone.setPointerCapture?.(e.pointerId);
  setStick(e.clientX, e.clientY);
  e.preventDefault();
});
stickZone.addEventListener('pointermove', e => {
  if (dragging && e.pointerId === pointerId) setStick(e.clientX, e.clientY);
});
stickZone.addEventListener('pointerup', clearStick);
stickZone.addEventListener('pointercancel', clearStick);

function axis() {
  let x = input.x, y = input.y;
  x += (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0);
  y += (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0);
  let m = Math.hypot(x, y);
  if (m < 0.16) return { x: 0, y: 0 };
  if (m > 1) { x /= m; y /= m; m = 1; }
  return { x, y };
}

function update(dt) {
  const a = axis();
  const max = world.player.walkSpeed;
  const movingInput = Math.abs(a.x) + Math.abs(a.y) > 0.01;
  const response = movingInput ? world.player.acceleration : world.player.deceleration;
  const t = 1 - Math.exp(-response * dt);
  const targetX = a.x * max;
  const targetY = a.y * max;
  player.vx += (targetX - player.vx) * t;
  player.vy += (targetY - player.vy) * t;

  const speed = Math.hypot(player.vx, player.vy);
  if (!movingInput && speed < 0.5) player.vx = player.vy = 0;
  player.moving = speed > 2;

  if (player.moving) {
    if (Math.abs(player.vx) > Math.abs(player.vy)) player.dir = player.vx > 0 ? 'right' : 'left';
    else player.dir = player.vy > 0 ? 'front' : 'back';
    player.anim = (player.anim + dt * (3.0 + Math.min(2.2, speed / 32))) % WALK.length;
    player.idle = 0;
  } else {
    player.anim = 0;
    player.idle += dt;
  }

  moveWithCollision(player.vx * dt, player.vy * dt);

  // hard fail-safe: never allow the protagonist to disappear from the legal map.
  if (!isWalkable(player.x, player.y)) {
    player.x = world.player.spawn.x;
    player.y = world.player.spawn.y;
    player.vx = player.vy = 0;
  }

  const visW = viewW / camera.zoom;
  const visH = viewH / camera.zoom;
  const minX = visW / 2, maxX = bg.width - visW / 2;
  const minY = visH / 2, maxY = bg.height - visH / 2;
  const tx = maxX < minX ? bg.width / 2 : Math.max(minX, Math.min(maxX, player.x));
  const ty = maxY < minY ? bg.height / 2 : Math.max(minY, Math.min(maxY, player.y));
  const follow = 1 - Math.exp(-4.2 * dt);
  camera.x += (tx - camera.x) * follow;
  camera.y += (ty - camera.y) * follow;

  // rain world simulation
  for (const p of rain) {
    p.y += p.speed * dt;
    p.x += p.drift * dt;
    if (p.y > bg.height + 20 || p.x > bg.width + 20) {
      p.y = -20;
      p.x = (p.x * 0.37 + 211) % bg.width;
    }
  }

  rippleClock -= dt;
  if (player.moving && rippleClock <= 0) {
    ripples.push({ x: player.x, y: player.y + 2, age: 0, life: 0.55 });
    rippleClock = 0.18;
  }
  for (const r of ripples) r.age += dt;
  ripples = ripples.filter(r => r.age < r.life);
}

function calcView() {
  const vw = viewW / camera.zoom;
  const vh = viewH / camera.zoom;
  let sx = camera.x - vw / 2;
  let sy = camera.y - vh / 2;
  sx = Math.max(0, Math.min(bg.width - vw, sx));
  sy = Math.max(0, Math.min(bg.height - vh, sy));
  if (bg.width < vw) sx = (bg.width - vw) / 2;
  if (bg.height < vh) sy = (bg.height - vh) / 2;
  return { vw, vh, sx, sy };
}

function playerLightAmount() {
  let amount = 0;
  for (const l of world.lights) {
    const d = Math.hypot(player.x - l.x, player.y - l.y);
    if (d < l.radius) amount += (1 - d / l.radius) * l.strength;
  }
  return Math.min(1, amount);
}

function drawPlayer() {
  const frame = player.moving ? WALK[Math.floor(player.anim) % WALK.length] % 4 : 0;
  const row = ROW[player.dir];
  const scale = world.player.scale;
  const dw = FW * scale;
  const dh = FH * scale;
  const x = player.x - dw / 2;
  const y = player.y - dh + 10;
  const light = playerLightAmount();

  // tight grounding shadow: reacts slightly to warm light sources.
  const shadowW = dw * 0.55;
  const shadowH = Math.max(7, dh * 0.09);
  ctx.globalAlpha = 0.34 + light * 0.08;
  ctx.drawImage(shadowAtlas, frame * 64, 0, 64, 32,
    player.x - shadowW / 2 - light * 3,
    player.y - shadowH / 2,
    shadowW, shadowH);
  ctx.globalAlpha = 1;

  // wet-ground reflection: short, dark, blurred only through alpha—not scale.
  ctx.save();
  ctx.globalAlpha = 0.09 + light * 0.05;
  ctx.translate(player.x, player.y + 8);
  ctx.scale(1, -0.42);
  ctx.filter = `brightness(${0.55 + light * 0.16}) saturate(0.7)`;
  ctx.drawImage(atlas, frame * FW, row * FH, FW, FH, -dw / 2, 0, dw, dh);
  ctx.restore();

  ctx.save();
  ctx.filter = `brightness(${0.90 + light * 0.20}) saturate(${1.02 + light * 0.12})`;
  ctx.drawImage(atlas, frame * FW, row * FH, FW, FH, x, y, dw, dh);
  ctx.restore();

  // restrained warm edge light, clipped around body footprint visually.
  if (light > 0.04) {
    const grad = ctx.createRadialGradient(player.x - dw * 0.18, player.y - dh * 0.62, 2,
      player.x, player.y - dh * 0.45, dw * 0.65);
    grad.addColorStop(0, `rgba(245,174,103,${0.12 * light})`);
    grad.addColorStop(1, 'rgba(245,174,103,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(x - 10, y - 10, dw + 20, dh + 20);
  }
}

function drawWorldLighting() {
  // cool 17:40 ambient layer
  ctx.save();
  ctx.fillStyle = 'rgba(38,34,70,0.17)';
  ctx.fillRect(0, 0, bg.width, bg.height);
  ctx.globalCompositeOperation = 'lighter';
  for (const l of world.lights) {
    const g = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.radius);
    const alpha = Math.max(0.06, Math.min(0.24, l.strength * 0.32));
    g.addColorStop(0, hexToRgba(l.color, alpha));
    g.addColorStop(0.38, hexToRgba(l.color, alpha * 0.55));
    g.addColorStop(1, hexToRgba(l.color, 0));
    ctx.fillStyle = g;
    ctx.fillRect(l.x - l.radius, l.y - l.radius, l.radius * 2, l.radius * 2);
  }
  ctx.restore();
}

function hexToRgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`;
}

function drawRain() {
  ctx.save();
  ctx.strokeStyle = 'rgba(191,194,225,0.25)';
  ctx.lineWidth = 1;
  for (const p of rain) {
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x - 2.5, p.y - p.len);
    ctx.stroke();
  }
  for (const r of ripples) {
    const q = r.age / r.life;
    ctx.strokeStyle = `rgba(205,190,225,${(1-q)*0.22})`;
    ctx.beginPath();
    ctx.ellipse(r.x, r.y, 4 + q * 11, 1.4 + q * 3.2, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function drawOccluders() {
  for (const o of world.occluders) {
    if (player.y < o.baselineY) {
      ctx.drawImage(bg, o.x, o.y, o.w, o.h, o.x, o.y, o.w, o.h);
    }
  }
}

function drawDebug() {
  ctx.save();
  ctx.lineWidth = 2 / camera.zoom;
  ctx.strokeStyle = '#4cff7a';
  ctx.fillStyle = 'rgba(76,255,122,.10)';
  polygonPath(world.walkPolygon); ctx.fill(); ctx.stroke();

  ctx.strokeStyle = '#ff4e70';
  ctx.fillStyle = 'rgba(255,78,112,.16)';
  for (const s of world.buildingHitboxes) drawShape(s);

  ctx.strokeStyle = '#ffb84e';
  ctx.fillStyle = 'rgba(255,184,78,.18)';
  for (const s of world.propHitboxes) drawShape(s);

  ctx.strokeStyle = '#66c7ff';
  ctx.beginPath();
  ctx.arc(player.x, player.y, world.player.footRadius, 0, Math.PI*2);
  ctx.stroke();
  ctx.restore();
}
function polygonPath(points) {
  ctx.beginPath();
  ctx.moveTo(points[0][0], points[0][1]);
  for (let i=1;i<points.length;i++) ctx.lineTo(points[i][0], points[i][1]);
  ctx.closePath();
}
function drawShape(s) {
  ctx.beginPath();
  if (s.type === 'rect') ctx.rect(s.x, s.y, s.w, s.h);
  else if (s.type === 'circle') ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
  else if (s.type === 'polygon') {
    ctx.moveTo(s.points[0][0], s.points[0][1]);
    for (let i=1;i<s.points.length;i++) ctx.lineTo(s.points[i][0], s.points[i][1]);
    ctx.closePath();
  }
  ctx.fill(); ctx.stroke();
}

function draw() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#100d19';
  ctx.fillRect(0, 0, viewW, viewH);

  const { sx, sy } = calcView();
  ctx.save();
  ctx.scale(camera.zoom, camera.zoom);
  ctx.translate(-sx, -sy);
  ctx.drawImage(bg, 0, 0);

  drawWorldLighting();
  drawRain();
  drawPlayer();
  drawOccluders();
  if (DEBUG) drawDebug();
  ctx.restore();
}

function loop(ts) {
  if (!last) last = ts;
  const dt = Math.min(0.033, Math.max(0, (ts - last) / 1000));
  last = ts;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}

boot().catch(err => {
  console.error(err);
  document.getElementById('labBadge').textContent = 'ERRO AO CARREGAR STREET LAB';
});
