(() => {
'use strict';

const DEBUG = new URLSearchParams(location.search).has('debug');
const WORLD = { width: 1448, height: 1086 };
const DIR_ROW = { down: 0, left: 1, right: 2, up: 3 };
const WALK = [0,1,2,3,2,1];

class StreetScene extends Phaser.Scene {
  constructor(){ super('Street'); }

  preload(){
    this.load.json('world','data/world.json?v=3');
    this.load.image('street','assets/backgrounds/exterior.webp');
    this.load.spritesheet('witch','assets/sprites/witch_walk_atlas.webp',{frameWidth:184,frameHeight:316});
    const fg = [
      ['fg_bench','assets/foreground/bench_left.png'],
      ['fg_bollard_left','assets/foreground/bollard_left.png'],
      ['fg_bollard_midleft','assets/foreground/bollard_midleft.png'],
      ['fg_bollard_mid','assets/foreground/bollard_mid.png'],
      ['fg_bollard_right','assets/foreground/bollard_right.png'],
      ['fg_lamp_right','assets/foreground/lamp_right.png'],
      ['fg_sign_cafe','assets/foreground/sign_cafe.png'],
      ['fg_planter_right','assets/foreground/planter_right.png']
    ];
    for(const [key,file] of fg) this.load.image(key,file);
  }

  create(){
    this.cfg = this.cache.json.get('world');
    window.__MYU_SCENE__ = this;
    this.speed = this.cfg.player.speed;
    this.vel = new Phaser.Math.Vector2();
    this.direction = 'down';
    this.animClock = 0;
    this.stepClock = 0;
    this.lastImpactAt = 0;

    this.add.image(0,0,'street').setOrigin(0).setDepth(-10000);

    // Matter is now authoritative: there is a real physical world and real static bodies.
    this.matter.world.setBounds(0,0,WORLD.width,WORLD.height,48,true,true,true,true);
    this.staticBodies = [];
    const addBox = (b, family) => {
      const body = this.matter.add.rectangle(b.x,b.y,b.w,b.h,{isStatic:true,label:`${family}:${b.id}`});
      body.plugin = body.plugin || {};
      body.plugin.myu = {family,id:b.id};
      this.staticBodies.push(body);
      return body;
    };
    this.cfg.buildingHitboxes.forEach(b=>addBox(b,'building'));
    this.cfg.propHitboxes.forEach(b=>addBox(b,'prop'));
    this.cfg.barriers.forEach(b=>addBox(b,'barrier'));

    // Tiny invisible Matter game object = the actual body at her feet.
    const px = this.add.graphics();
    px.fillStyle(0xffffff,1); px.fillRect(0,0,2,2); px.generateTexture('bodyPixel',2,2); px.destroy();
    this.playerBody = this.matter.add.image(this.cfg.player.spawn.x,this.cfg.player.spawn.y,'bodyPixel');
    this.playerBody.setCircle(this.cfg.player.bodyRadius);
    this.playerBody.setFixedRotation();
    this.playerBody.setIgnoreGravity(true);
    this.playerBody.setFriction(0,0,0);
    this.playerBody.setFrictionAir(0.18);
    this.playerBody.setBounce(0);
    this.playerBody.setVisible(DEBUG);
    if(DEBUG) this.playerBody.setTint(0x00ff66).setAlpha(.85).setScale(8);

    const scale = this.cfg.player.spriteScale;
    this.reflection = this.add.sprite(this.playerBody.x,this.playerBody.y+7,'witch',0)
      .setOrigin(.5,0).setFlipY(true).setScale(scale,.13).setTint(0x777ca8).setAlpha(.10).setDepth(-20);
    this.shadow = this.add.ellipse(this.playerBody.x,this.playerBody.y+1,46,14,0x14101d,.38).setDepth(0);
    this.player = this.add.sprite(this.playerBody.x,this.playerBody.y,'witch',0).setOrigin(.5,.95).setScale(scale).setDepth(this.playerBody.y);
    this.warmOverlay = this.add.sprite(this.playerBody.x,this.playerBody.y,'witch',0)
      .setOrigin(.5,.95).setScale(scale).setTint(0xffb369).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0).setDepth(this.playerBody.y+.01);

    this.foreground = [];
    for(const f of this.cfg.foreground){
      const obj = this.add.image(f.x,f.y,f.key).setOrigin(0).setDepth(f.depthY);
      this.foreground.push({obj,depthY:f.depthY});
    }

    this.createRain();
    this.createInput();

    const cam = this.cameras.main;
    cam.setBounds(0,0,WORLD.width,WORLD.height);
    const mobileZoom = Math.max(.72, Math.min(.88, innerWidth/900));
    cam.setZoom(innerWidth < innerHeight ? mobileZoom : .92);
    cam.startFollow(this.playerBody,true,.10,.10);
    cam.setDeadzone(Math.min(220,innerWidth*.22),Math.min(150,innerHeight*.13));
    cam.roundPixels = true;

    if(DEBUG){
      this.drawDesignDebug();
    }

    // Physical collision feedback: environment actually knows she hit something.
    this.matter.world.on('collisionstart',(event)=>{
      for(const pair of event.pairs){
        const a = pair.bodyA, b = pair.bodyB;
        const hit = a===this.playerBody.body ? b : (b===this.playerBody.body ? a : null);
        if(!hit) continue;
        const now = performance.now();
        if(now-this.lastImpactAt>140){
          this.lastImpactAt=now;
          if(navigator.vibrate) navigator.vibrate(5);
          this.makeContactRipple(this.playerBody.x,this.playerBody.y,0x776e91,.16);
        }
      }
    });
  }

  createInput(){
    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = this.input.keyboard.addKeys('W,A,S,D');
    this.joy = {x:0,y:0,active:false};
    const zone=document.getElementById('stickZone');
    const base=document.getElementById('stickBase');
    const knob=document.getElementById('stickKnob');
    let pointer=null, center={x:0,y:0}, radius=1;
    const refresh=()=>{const r=base.getBoundingClientRect();center={x:r.left+r.width/2,y:r.top+r.height/2};radius=r.width*.36;};
    const set=(e)=>{const dx=e.clientX-center.x,dy=e.clientY-center.y,n=Math.hypot(dx,dy)||1,m=Math.min(n,radius),mx=dx/n*m,my=dy/n*m;this.joy.x=mx/radius;this.joy.y=my/radius;this.joy.active=true;knob.style.left=`calc(29% + ${mx}px)`;knob.style.top=`calc(29% + ${my}px)`;};
    const clear=()=>{pointer=null;this.joy.x=this.joy.y=0;this.joy.active=false;knob.style.left='29%';knob.style.top='29%';};
    zone.addEventListener('pointerdown',e=>{refresh();pointer=e.pointerId;zone.setPointerCapture?.(pointer);set(e);e.preventDefault();});
    zone.addEventListener('pointermove',e=>{if(pointer===e.pointerId)set(e)});
    zone.addEventListener('pointerup',e=>{if(pointer===e.pointerId)clear()});
    zone.addEventListener('pointercancel',clear);
  }

  createRain(){
    this.rain=[];
    const count=innerWidth<700?45:80;
    for(let i=0;i<count;i++){
      const x=Math.random()*WORLD.width,y=450+Math.random()*470;
      const drop=this.add.rectangle(x,y,1,5,0xb9b8d4,.18+Math.random()*.18).setDepth(9990);
      this.rain.push({drop,speed:80+Math.random()*70,drift:-10-Math.random()*10});
    }
  }

  drawDesignDebug(){
    const g=this.add.graphics().setDepth(99999);
    const draw=(list,color)=>{g.lineStyle(2,color,.9);for(const b of list){g.strokeRect(b.x-b.w/2,b.y-b.h/2,b.w,b.h);}};
    draw(this.cfg.buildingHitboxes,0xff3344);draw(this.cfg.propHitboxes,0xffaa00);draw(this.cfg.barriers,0xff00ff);
    g.lineStyle(2,0x00ff88,.95);g.strokeCircle(this.cfg.player.spawn.x,this.cfg.player.spawn.y,this.cfg.player.bodyRadius);
  }

  getAxis(){
    let x=this.joy.x,y=this.joy.y;
    if(this.keys.A.isDown||this.cursors.left.isDown)x-=1;
    if(this.keys.D.isDown||this.cursors.right.isDown)x+=1;
    if(this.keys.W.isDown||this.cursors.up.isDown)y-=1;
    if(this.keys.S.isDown||this.cursors.down.isDown)y+=1;
    const m=Math.hypot(x,y);if(m>1){x/=m;y/=m;}
    if(m<.16 && this.joy.active) return {x:0,y:0};
    return {x,y};
  }

  makeContactRipple(x,y,color=0xa9a5c8,alpha=.24){
    const e=this.add.ellipse(x,y+3,20,7).setStrokeStyle(1,color,alpha).setFillStyle(0x000000,0).setDepth(y-1);
    this.tweens.add({targets:e,scaleX:1.8,scaleY:1.8,alpha:0,duration:320,ease:'Quad.Out',onComplete:()=>e.destroy()});
  }

  makeStepReaction(){
    const x=this.playerBody.x,y=this.playerBody.y;
    this.makeContactRipple(x,y,0xb8b4d4,.18);
    if(Math.random()<.45){
      const leaf=this.add.rectangle(x+(Math.random()-.5)*16,y+(Math.random()-.5)*8,4,2,Math.random()<.5?0x8a4056:0xa35062,.7).setDepth(y+2).setAngle(Math.random()*180);
      this.tweens.add({targets:leaf,x:leaf.x+(Math.random()-.5)*22,y:leaf.y-8-Math.random()*8,angle:leaf.angle+90,alpha:0,duration:420,onComplete:()=>leaf.destroy()});
    }
  }

  updateRain(dt){
    const minY=440,maxY=930;
    for(const r of this.rain){
      r.drop.y+=r.speed*dt;r.drop.x+=r.drift*dt;
      if(r.drop.y>maxY){r.drop.y=minY-Math.random()*60;r.drop.x=Math.random()*WORLD.width;}
      if(r.drop.x<0)r.drop.x=WORLD.width;
    }
  }

  update(time,delta){
    const dt=Math.min(.033,delta/1000);
    const a=this.getAxis();
    const moving=Math.abs(a.x)+Math.abs(a.y)>.02;
    const targetX=moving?a.x*this.speed:0,targetY=moving?a.y*this.speed:0;
    const blend=1-Math.exp(-this.cfg.player.acceleration*dt);
    this.vel.x=Phaser.Math.Linear(this.vel.x,targetX,blend);
    this.vel.y=Phaser.Math.Linear(this.vel.y,targetY,blend);
    if(!moving && Math.hypot(this.vel.x,this.vel.y)<.5)this.vel.set(0,0);
    this.playerBody.setVelocity(this.vel.x,this.vel.y);

    // Never leave the designed play area even if a physics edge case occurs.
    const hardX=Phaser.Math.Clamp(this.playerBody.x,20,WORLD.width-20);
    const hardY=Phaser.Math.Clamp(this.playerBody.y,470,this.cfg.world.southLimit-12);
    if(hardX!==this.playerBody.x||hardY!==this.playerBody.y){
      this.playerBody.setPosition(hardX,hardY);this.vel.scale(.2);
    }

    if(moving){
      if(Math.abs(a.x)>Math.abs(a.y))this.direction=a.x<0?'left':'right';else this.direction=a.y<0?'up':'down';
      this.animClock+=dt*(2.5+Math.hypot(this.vel.x,this.vel.y)/this.speed*3.2);
      this.stepClock+=dt;
      if(this.stepClock>.34){this.stepClock=0;this.makeStepReaction();}
    } else {
      this.animClock=0;this.stepClock=.15;
    }
    const frame=moving?WALK[Math.floor(this.animClock)%WALK.length]:0;
    const atlasFrame=DIR_ROW[this.direction]*4+frame;
    this.player.setFrame(atlasFrame);this.warmOverlay.setFrame(atlasFrame);this.reflection.setFrame(atlasFrame);

    const x=this.playerBody.x,y=this.playerBody.y;
    const bob=moving?Math.sin(this.animClock*Math.PI)*1.2:0;
    this.player.setPosition(x,y-bob).setDepth(y);
    this.warmOverlay.setPosition(x,y-bob).setDepth(y+.02);
    this.reflection.setPosition(x,y+6).setDepth(y-20);

    // Warm light reacts to her actual position. The nearer she is to a lit window/lamp,
    // the warmer she gets and the more the wet-ground reflection appears.
    let warm=0,nearest=null,nearestD=Infinity;
    for(const l of this.cfg.warmLights){
      const d=Math.hypot(x-l.x,y-l.y);const t=Math.max(0,1-d/l.radius);warm=Math.max(warm,t*l.strength);
      if(d<nearestD){nearestD=d;nearest=l;}
    }
    this.warmOverlay.setAlpha(Math.min(.24,warm));
    this.reflection.setAlpha(.07+warm*.35);

    let sx=0,sy=0;
    if(nearest){const dx=x-nearest.x,dy=y-nearest.y,m=Math.hypot(dx,dy)||1;sx=dx/m*(4+warm*22);sy=dy/m*(1.5+warm*8);}
    this.shadow.setPosition(x+sx,y+2+sy).setScale(1+warm*.35,1-warm*.12).setAlpha(.36-warm*.08).setDepth(y-2);

    // Foreground pieces have their own Y-depth anchors: she can be behind or in front
    // of a real object instead of always painting over the entire backdrop.
    for(const f of this.foreground) f.obj.setDepth(f.depthY);

    this.updateRain(dt);
  }
}

const config={
  type:Phaser.WEBGL,
  parent:'game',
  width:innerWidth,
  height:innerHeight,
  backgroundColor:'#120f1f',
  pixelArt:true,
  antialias:false,
  roundPixels:true,
  scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},
  physics:{default:'matter',matter:{gravity:{x:0,y:0},debug:DEBUG}},
  scene:[StreetScene]
};
new Phaser.Game(config);
})();
