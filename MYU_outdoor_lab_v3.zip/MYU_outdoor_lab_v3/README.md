# MYU — Outdoor Engine Lab v3

Esta build continua em **JavaScript + Phaser 4.2.1** (não Godot) e mantém a cafeteria fora do escopo.

## Correções principais
- velocidade máxima reduzida de 92 para **50 px/s**;
- aceleração e desaceleração suavizadas;
- prédio com corpos estáticos Matter contínuos, sem frestas;
- segunda camada de colisão determinística antes de qualquer deslocamento;
- protagonista só pode ocupar pontos válidos do polígono caminhável;
- `lastSafe` impede a protagonista de desaparecer/sair do mapa mesmo se a física sofrer um erro;
- obstáculos visíveis continuam sólidos;
- hitbox da protagonista concentrada nos pés;
- protagonista ligeiramente maior para integrar melhor com a escala do cenário;
- reação visual curta ao bater em uma superfície sólida;
- assets e dados carregados com cache-busting `v3-physics`.

## Testes
1. Spawn válido — PASS
2. Prédio bloqueia movimento para cima — PASS
3. Limite inferior do mapa não pode ser atravessado — PASS
4. Limite lateral não pode ser atravessado — PASS
5. Velocidade máxima = 50 px/s — PASS

Use `?debug=1` para visualizar as geometrias de colisão.
