# MYU Outdoor Engine Lab v3

Correção estrutural da rua.

## Mudanças
- velocidade reduzida para 60 px/s;
- protagonista ampliada para 36% do atlas (~114 px de altura visual);
- prédio principal possui hitbox poligonal física;
- circulação limitada ao contorno real da calçada;
- hitboxes individuais para banco, placa, vasos, postes/bollards, luminária, jardineira e sinalização;
- sistema de oclusão reaplica partes do cenário à frente da protagonista quando ela passa atrás;
- câmera limitada ao tamanho real do mapa: protagonista não pode sumir para fora da imagem;
- fail-safe reposiciona no spawn caso alguma coordenada inválida escape da geometria;
- sombra curta presa aos pés;
- reflexo sutil no piso molhado;
- chuva e pequenas ondulações ao caminhar;
- iluminação 17:40 com base fria e luzes quentes locais.

## Debug
Adicione `?debug=1` à URL para ver:
- verde: área caminhável;
- vermelho: prédio;
- laranja: props físicos;
- azul: hitbox dos pés.
