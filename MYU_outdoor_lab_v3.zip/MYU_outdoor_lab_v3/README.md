# MYU — Outdoor Engine Lab v3

Correção estrutural do laboratório de rua.

## O que agora é físico de verdade
- prédio: quatro corpos estáticos Matter alinhados às partes visíveis da fachada;
- banco, placa, vaso, balizadores, poste, jardineira e placa da direita: corpos estáticos próprios;
- margem do mapa e corrimão: barreiras Matter;
- protagonista: corpo circular pequeno concentrado nos pés;
- câmera presa aos limites do mundo.

## Movimento
- velocidade máxima: **54 px/s** (antes 92);
- aceleração/desaceleração suavizadas;
- hard clamp adicional para impedir qualquer desaparecimento fora da área jogável.

## Integração visual com a rua
- sprite maior: escala 0.34;
- foregrounds individuais para banco, balizadores, poste, placa e jardineira;
- depth sorting por Y;
- sombra muda direção conforme a fonte de luz mais próxima;
- highlight âmbar aumenta perto das janelas/luminária;
- reflexo discreto da protagonista no piso molhado;
- ondulação a cada passo;
- folhas pequenas reagem à passagem;
- chuva em primeiro plano.

## Debug
Use `?debug=1` para visualizar os corpos Matter e os limites de design.
