# MYU Street Lab v3

Esta build substitui o v2 e foi reconstruída para corrigir os problemas reportados no celular.

## Correções concretas
- prédio com 4 caixas de colisão sobrepostas acompanhando a fachada;
- personagem não pode sair da área caminhável da calçada;
- velocidade máxima reduzida para 58 px/s;
- câmera presa ao mundo e seguindo apenas horizontalmente no retrato;
- protagonista aumentada para escala 0.285 do atlas;
- hitbox física apenas nos pés (raio 11);
- postes, banco, jardineiras, placa, corrimão e placas de direção possuem colisão;
- foreground patches redesenham objetos por cima da protagonista quando ela passa atrás;
- sombra reage à luminária mais próxima;
- sprite recebe leve aquecimento perto de luzes quentes;
- reflexo curto no piso molhado;
- ondulações aparecem nos passos;
- `?debug=1` mostra área caminhável e hitboxes.

## Testes locais
- spawn válido: PASS
- 4 pontos da fachada do prédio bloqueados: PASS
- 4 pontos livres da calçada caminháveis: PASS
- 3 pontos da rua/fora do mapa bloqueados: PASS
- velocidade máxima 58: PASS
- sintaxe de `app.js`: PASS (`node --check`)
