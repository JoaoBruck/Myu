(() => {
'use strict';

const WORLD = { w: 1448, h: 1086 };
const PLAYER = { frameW:184, frameH:316, scale:0.285, footRadius:11, maxSpeed:58, accel:250, brake:320 };
const DEBUG = new URLSearchParams(location.search).get('debug') === '1';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha:false });
const debugBadge = document.getElementById('debugBadge');
const stickZone = document.getElementById('stickZone');
const stickKnob = document.getElementById('stickKnob');
const actionBtn = document.getElementById('action');
if (DEBUG) debugBadge.hidden = false;
ctx.imageSmoothingEnabled = false;

const assets = {};
const keys = new Set();
const joy = { x:0, y:0, active:false, pointer:null, cx:0, cy:0, radius:1 };
const player = { x:515, y:690, vx:0, vy:0, dir:'front', anim:0, moving:false };
const camera = { x:player.x, y:WORLD.h/2, zoom:1, viewW:0, viewH:0 };
const ripples = [];
let last=0, rippleCooldown=0;

// A calçada é o mapa. Fora dela não existe caminho jogável.
const WALK_POLY = [
  [0,488],[170,468],[320,500],[500,520],[705,528],[900,510],[1040,486],[1190,505],[1448,575],
  [1448,760],[1325,780],[1185,760],[1040,745],[910,795],[730,815],[520,800],[330,770],[145,710],[0,650]
];

// O prédio é físico: quatro caixas sobrepostas acompanham a fachada inferior.
const BUILDING_HITBOXES = [
  {x:0,   y:0, w:310, h:478, kind:'building'},
  {x:285, y:0, w:370, h:515, kind:'building'},
  {x:620, y:0, w:300, h:538, kind:'building'},
  {x:885, y:0, w:160, h:505, kind:'building'}
];

const OBJECT_HITBOXES = [
  {x:0,y:400,w:155,h:76,kind:'bench'},
  {x:300,y:420,w:375,h:90,kind:'planters'},
  {x:612,y:485,w:78,h:94,kind:'chalkboard'},
  {x:808,y:465,w:95,h:118,kind:'planter'},
  {x:1094,y:112,w:52,h:505,kind:'lamp'},
  {x:1160,y:470,w:150,h:154,kind:'planter'},
  {x:1260,y:610,w:188,h:158,kind:'signs'},
  {x:1185,y:350,w:263,h:72,kind:'railing'},
  {x:1305,y:420,w:143,h:184,kind:'railing'},
  {x:28,y:500,w:28,h:92,kind:'bollard'},
  {x:165,y:535,w:28,h:96,kind:'bollard'},
  {x:286,y:575,w:30,h:100,kind:'bollard'},
  {x:431,y:626,w:31,h:106,kind:'bollard'},
  {x:776,y:665,w:30,h:105,kind:'bollard'}
];
const HITBOXES = [...BUILDING_HITBOXES, ...OBJECT_HITBOXES];

// Partes do cenário que precisam voltar a ser desenhadas por cima da personagem quando ela passa atrás.
const FOREGROUND = [
  {x:18,y:464,w:56,h:150,baseY:590},
  {x:150,y:500,w:62,h:160,baseY:632},
  {x:270,y:540,w:64,h:166,baseY:676},
  {x:415,y:590,w:72,h:180,baseY:734},
  {x:755,y:625,w:72,h:175,baseY:772},
  {x:1070,y:85,w:105,h:560,baseY:618},
  {x:1138,y:442,w:205,h:225,baseY:635},
  {x:1230,y:570,w:218,h:235,baseY:775}
];

const LIGHTS = [
  {x:470,y:330,r:235,power:.10},
  {x:565,y:330,r:235,power:.10},
  {x:665,y:350,r:220,power:.12},
  {x:845,y:380,r:240,power:.18},
  {x:1118,y:320,r:300,power:.16}
];

const WALK = [0,1,2,3,2,1];
const rows = {front:0,left:1,right:2,back:3};

function loadImage(src){
  return new Promise((resolve,reject)=>{
    const im=new Image();
    im.onload=()=>resolve(im); im.onerror=reject; im.src=src;
  });
}

async function boot(){
  try{
    const [bg, sprite] = await Promise.all([
      loadImage('../assets/backgrounds/exterior.webp?v=15'),
      loadImage('../assets/sprites/witch_walk_atlas.webp?v=15')
    ]);
    assets.bg=bg; assets.sprite=sprite;
    assets.spriteFx=document.createElement('canvas');
    assets.spriteFx.width=PLAYER.frameW; assets.spriteFx.height=PLAYER.frameH;
    resize();
    requestAnimationFrame(loop);
  }catch(err){
    document.getElementById('status').textContent='ERRO AO CARREGAR ASSETS';
    console.error(err);
  }
}

function resize(){
  const r=canvas.getBoundingClientRect();
  const dpr=Math.max(1,Math.min(2,devicePixelRatio||1));
  canvas.width=Math.round(r.width*dpr); canvas.height=Math.round(r.height*dpr);
  ctx.setTransform(dpr,0,0,dpr,0,0); ctx.imageSmoothingEnabled=false;
  // A altura inteira do mapa quase cabe no celular; a câmera só acompanha horizontalmente.
  camera.zoom=(r.height/WORLD.h)*1.025;
  camera.viewW=r.width/camera.zoom; camera.viewH=r.height/camera.zoom;
  camera.y=WORLD.h/2;
}
addEventListener('resize', resize, {passive:true});

function pointInPoly(x,y,poly){
  let inside=false;
  for(let i=0,j=poly.length-1;i<poly.length;j=i++){
    const xi=poly[i][0], yi=poly[i][1], xj=poly[j][0], yj=poly[j][1];
    const cross=((yi>y)!==(yj>y)) && (x < (xj-xi)*(y-yi)/((yj-yi)||1e-9)+xi);
    if(cross) inside=!inside;
  }
  return inside;
}

function circleRect(cx,cy,r,b){
  const nx=Math.max(b.x,Math.min(cx,b.x+b.w));
  const ny=Math.max(b.y,Math.min(cy,b.y+b.h));
  const dx=cx-nx, dy=cy-ny;
  return dx*dx+dy*dy < r*r;
}

function walkable(x,y){
  const r=PLAYER.footRadius;
  const probes=[[0,0],[r,0],[-r,0],[0,r*.65],[0,-r*.65],[r*.7,r*.45],[-r*.7,r*.45]];
  for(const [ox,oy] of probes) if(!pointInPoly(x+ox,y+oy,WALK_POLY)) return false;
  for(const b of HITBOXES) if(circleRect(x,y,r,b)) return false;
  return true;
}

function inputAxis(){
  let x=joy.x,y=joy.y;
  if(keys.has('a')||keys.has('arrowleft')) x-=1;
  if(keys.has('d')||keys.has('arrowright')) x+=1;
  if(keys.has('w')||keys.has('arrowup')) y-=1;
  if(keys.has('s')||keys.has('arrowdown')) y+=1;
  const n=Math.hypot(x,y);
  if(n>1){x/=n;y/=n;}
  return {x,y};
}

addEventListener('keydown',e=>{const k=e.key.toLowerCase(); if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();keys.add(k)});
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));

actionBtn.addEventListener('pointerdown',e=>{e.preventDefault(); navigator.vibrate?.(7)});

function refreshJoy(){
  const r=stickZone.getBoundingClientRect(); joy.cx=r.left+r.width/2;joy.cy=r.top+r.height/2;joy.radius=r.width*.34;
}
function moveJoy(e){
  const dx=e.clientX-joy.cx,dy=e.clientY-joy.cy,n=Math.hypot(dx,dy)||1,m=Math.min(n,joy.radius);
  const mx=dx/n*m,my=dy/n*m; joy.x=mx/joy.radius;joy.y=my/joy.radius;
  stickKnob.style.transform=`translate(calc(-50% + ${mx}px),calc(-50% + ${my}px))`;
}
stickZone.addEventListener('pointerdown',e=>{refreshJoy();joy.active=true;joy.pointer=e.pointerId;stickZone.setPointerCapture(e.pointerId);moveJoy(e);e.preventDefault()});
stickZone.addEventListener('pointermove',e=>{if(joy.active&&e.pointerId===joy.pointer)moveJoy(e)});
function endJoy(e){if(e.pointerId!==joy.pointer)return;joy.active=false;joy.pointer=null;joy.x=joy.y=0;stickKnob.style.transform='translate(-50%,-50%)'}
stickZone.addEventListener('pointerup',endJoy);stickZone.addEventListener('pointercancel',endJoy);

function update(dt){
  const a=inputAxis();
  const active=Math.abs(a.x)+Math.abs(a.y)>.02;
  const targetX=a.x*PLAYER.maxSpeed,targetY=a.y*PLAYER.maxSpeed;
  const rate=active?PLAYER.accel:PLAYER.brake;
  const blend=Math.min(1,rate*dt/Math.max(1,PLAYER.maxSpeed));
  player.vx+=(targetX-player.vx)*blend;player.vy+=(targetY-player.vy)*blend;
  if(Math.abs(player.vx)<.04)player.vx=0;if(Math.abs(player.vy)<.04)player.vy=0;

  const nx=player.x+player.vx*dt;
  if(walkable(nx,player.y)) player.x=nx; else player.vx=0;
  const ny=player.y+player.vy*dt;
  if(walkable(player.x,ny)) player.y=ny; else player.vy=0;

  // Garantia redundante: mesmo com frame perdido, nunca sai do mundo jogável.
  player.x=Math.max(PLAYER.footRadius,Math.min(WORLD.w-PLAYER.footRadius,player.x));
  player.y=Math.max(PLAYER.footRadius,Math.min(WORLD.h-PLAYER.footRadius,player.y));

  const sp=Math.hypot(player.vx,player.vy);
  player.moving=sp>1.5;
  if(player.moving){
    player.dir=Math.abs(player.vx)>Math.abs(player.vy)?(player.vx<0?'left':'right'):(player.vy<0?'back':'front');
    player.anim=(player.anim+dt*(2.2+sp/28))%WALK.length;
  }else player.anim=0;

  // Câmera horizontal amortecida e sempre presa dentro do mapa.
  const desiredX=player.x;
  camera.x+=(desiredX-camera.x)*Math.min(1,dt*4.6);
  const half=camera.viewW/2;
  camera.x=Math.max(half,Math.min(WORLD.w-half,camera.x));

  rippleCooldown-=dt;
  if(player.moving && rippleCooldown<=0){
    ripples.push({x:player.x,y:player.y+4,life:1});
    rippleCooldown=.32;
  }
  for(const r of ripples)r.life-=dt*1.5;
  while(ripples.length&&ripples[0].life<=0)ripples.shift();
}

function warmAmount(){
  let a=0;
  for(const l of LIGHTS){const d=Math.hypot(player.x-l.x,player.y-l.y);const t=Math.max(0,1-d/l.r);a=Math.max(a,t*l.power)}
  return Math.min(.18,a);
}
function nearestLight(){
  let best=LIGHTS[0],dist=Infinity;
  for(const l of LIGHTS){const d=Math.hypot(player.x-l.x,player.y-l.y);if(d<dist){dist=d;best=l}}
  return best;
}

function drawPlayer(){
  const atlas=assets.sprite;
  const frame=player.moving?WALK[Math.floor(player.anim)%WALK.length]:0;
  const row=rows[player.dir];
  const fw=PLAYER.frameW,fh=PLAYER.frameH;
  const dw=fw*PLAYER.scale,dh=fh*PLAYER.scale;
  const x=player.x-dw/2,y=player.y-dh+8;

  // sombra reage à luminária mais próxima
  const l=nearestLight();let dx=player.x-l.x,dy=player.y-l.y;const n=Math.hypot(dx,dy)||1;dx/=n;dy/=n;
  ctx.save();ctx.globalAlpha=.42;ctx.fillStyle='#171322';ctx.beginPath();ctx.ellipse(player.x+dx*5,player.y+dy*2,22,7,0,0,Math.PI*2);ctx.fill();ctx.restore();

  const fx=assets.spriteFx, fctx=fx.getContext('2d');
  fctx.clearRect(0,0,fw,fh);fctx.imageSmoothingEnabled=false;
  fctx.drawImage(atlas,frame*fw,row*fh,fw,fh,0,0,fw,fh);
  const warm=warmAmount();
  if(warm>0){fctx.globalCompositeOperation='source-atop';fctx.fillStyle=`rgba(255,177,103,${warm})`;fctx.fillRect(0,0,fw,fh);fctx.globalCompositeOperation='source-over'}

  ctx.drawImage(fx,0,0,fw,fh,x,y,dw,dh);

  // reflexo curto e discreto no piso molhado
  ctx.save();ctx.globalAlpha=.075;ctx.translate(player.x,player.y+5);ctx.scale(1,-.32);ctx.drawImage(fx,0,0,fw,fh,-dw/2,0,dw,dh);ctx.restore();
}

function drawRipples(){
  for(const r of ripples){ctx.save();ctx.globalAlpha=Math.max(0,r.life)*.24;ctx.strokeStyle='#d7c7d8';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(r.x,r.y,4+(1-r.life)*11,1.5+(1-r.life)*3,0,0,Math.PI*2);ctx.stroke();ctx.restore()}
}

function drawForeground(){
  for(const f of FOREGROUND){
    if(player.y < f.baseY){ctx.drawImage(assets.bg,f.x,f.y,f.w,f.h,f.x,f.y,f.w,f.h)}
  }
}

function drawDebug(){
  if(!DEBUG)return;
  ctx.save();
  ctx.fillStyle='rgba(30,220,90,.14)';ctx.strokeStyle='rgba(70,255,130,.75)';ctx.lineWidth=2;
  ctx.beginPath();WALK_POLY.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();ctx.stroke();
  for(const b of HITBOXES){ctx.fillStyle=b.kind==='building'?'rgba(255,45,45,.28)':'rgba(255,150,30,.23)';ctx.strokeStyle=b.kind==='building'?'#ff5757':'#ffab4a';ctx.fillRect(b.x,b.y,b.w,b.h);ctx.strokeRect(b.x,b.y,b.w,b.h)}
  ctx.fillStyle='#65d9ff';ctx.beginPath();ctx.arc(player.x,player.y,PLAYER.footRadius,0,Math.PI*2);ctx.fill();
  ctx.restore();
}

function render(){
  const rect=canvas.getBoundingClientRect();
  ctx.save();
  ctx.setTransform((canvas.width/rect.width),0,0,(canvas.height/rect.height),0,0);
  ctx.fillStyle='#151321';ctx.fillRect(0,0,rect.width,rect.height);
  ctx.scale(camera.zoom,camera.zoom);
  const worldViewW=rect.width/camera.zoom, worldViewH=rect.height/camera.zoom;
  const sx=camera.x-worldViewW/2,sy=camera.y-worldViewH/2;
  ctx.translate(-sx,-sy);
  ctx.drawImage(assets.bg,0,0,WORLD.w,WORLD.h);
  drawRipples();
  drawPlayer();
  drawForeground();
  drawDebug();
  ctx.restore();
}

function loop(t){
  if(!last)last=t;const dt=Math.min(.033,(t-last)/1000);last=t;update(dt);render();requestAnimationFrame(loop)
}

boot();
})();
