(() => {
'use strict';

const DEBUG = new URLSearchParams(location.search).has('debug');
const DIR_ROW = { down: 0, left: 1, right: 2, up: 3 };
const WALK = [0, 1, 2, 3, 2, 1];

class StreetScene extends Phaser.Scene {
  constructor(){ super('Street'); }

  preload(){
    this.load.json('world', 'data/world.json?v=6');
    this.load.image('street', 'assets/backgrounds/exterior.webp');
    this.load.spritesheet('witch', 'assets/sprites/witch_walk_atlas.webp', { frameWidth:184, frameHeight:316 });
    const fg = [
      ['fg_bench','assets/foreground/bench_left.png'],
      ['fg_bollard_left','assets/foreground/bollard_left.png'],
      ['fg_bollard_midleft','assets/foreground/bollard_midleft.png'],
      ['fg_bollard_mid','assets/foreground/bollard_mid.png'],
      ['fg_bollard_right','assets/foreground/bollard_right.png'],
      ['fg_lamp_right','assets/foreground/lamp_right.png'],
      ['fg_sign_cafe','assets/foreground/sign_cafe.png'],
      ['fg_planter_right','assets/foreground/planter_right.png']
    ];
    for (const [key,file] of fg) this.load.image(key,file);
  }

  create(){
    this.cfg = this.cache.json.get('world');
    this.W = this.cfg.world.width;
    this.H = this.cfg.world.height;
    window.__MYU_SCENE__ = this;

    this.speed = this.cfg.player.speed;
    this.velocity = new Phaser.Math.Vector2();
    this.direction = 'down';
    this.animClock = 0;
    this.stepClock = 0;
    this.lastImpactAt = 0;

    this.add.image(0,0,'street').setOrigin(0).setDepth(-10000);

    // Arcade Physics is used here on purpose: top-down walking needs predictable px/s
    // and reliable immovable walls more than rigid-body dynamics.
    this.physics.world.setBounds(0, this.cfg.world.playTop, this.W, this.cfg.world.playBottom - this.cfg.world.playTop);

    this.staticBodies = [];
    const addStaticBox = (b, family, color) => {
      const box = this.add.rectangle(b.x,b.y,b.w,b.h,color,DEBUG ? 0.18 : 0).setDepth(DEBUG ? 20000 : -9999);
      this.physics.add.existing(box, true);
      box.body.updateFromGameObject?.();
      box.setData('family', family);
      box.setData('id', b.id);
      this.staticBodies.push(box);
      return box;
    };

    this.cfg.buildingHitboxes.forEach(b => addStaticBox(b,'building',0xff3344));
    this.cfg.propHitboxes.forEach(b => addStaticBox(b,'prop',0xffaa00));
    this.cfg.barriers.forEach(b => addStaticBox(b,'barrier',0xff00ff));

    // The physical body is deliberately tiny and located at her feet.
    this.bodyVisual = this.add.rectangle(this.cfg.player.spawn.x,this.cfg.player.spawn.y,
      this.cfg.player.bodyWidth,this.cfg.player.bodyHeight,0x00ff66,DEBUG ? .8 : 0).setDepth(20001);
    this.physics.add.existing(this.bodyVisual);
    this.playerBody = this.bodyVisual;
    this.playerBody.body.setAllowGravity(false);
    this.playerBody.body.setCollideWorldBounds(true);
    this.playerBody.body.setMaxVelocity(this.speed,this.speed);

    for(const wall of this.staticBodies){
      this.physics.add.collider(this.playerBody, wall, () => this.onWorldContact(wall));
    }

    const scale = this.cfg.player.spriteScale;
    this.reflection = this.add.sprite(this.playerBody.x,this.playerBody.y+7,'witch',0)
      .setOrigin(.5,0).setFlipY(true).setScale(scale,.14).setTint(0x777ca8).setAlpha(.10).setDepth(-20);
    this.shadow = this.add.ellipse(this.playerBody.x,this.playerBody.y+1,48,14,0x14101d,.38).setDepth(0);
    this.player = this.add.sprite(this.playerBody.x,this.playerBody.y,'witch',0)
      .setOrigin(.5,.95).setScale(scale).setDepth(this.playerBody.y);
    this.warmOverlay = this.add.sprite(this.playerBody.x,this.playerBody.y,'witch',0)
      .setOrigin(.5,.95).setScale(scale).setTint(0xffb369).setBlendMode(Phaser.BlendModes.ADD)
      .setAlpha(0).setDepth(this.playerBody.y+.01);

    this.foreground = [];
    for(const f of this.cfg.foreground){
      const obj = this.add.image(f.x,f.y,f.key).setOrigin(0).setDepth(f.depthY);
      this.foreground.push({obj,depthY:f.depthY});
    }

    this.createRain();
    this.createInput();

    const cam = this.cameras.main;
    cam.setBounds(0,0,this.W,this.H);
    const portrait = innerHeight > innerWidth;
    const mobileZoom = portrait ? Math.max(.74, Math.min(.88, innerWidth/790)) : .94;
    cam.setZoom(mobileZoom);
    cam.startFollow(this.playerBody,true,.08,.08);
    cam.setDeadzone(Math.min(190,innerWidth*.20),Math.min(125,innerHeight*.11));
    cam.roundPixels = true;

    if(DEBUG) this.drawDesignDebug();
  }

  onWorldContact(wall){
    const now = performance.now();
    if(now - this.lastImpactAt < 120) return;
    this.lastImpactAt = now;
    this.velocity.scale(.25);
    if(navigator.vibrate) navigator.vibrate(4);
    this.makeContactRipple(this.playerBody.x,this.playerBody.y,0x776e91,.14);
  }

  createInput(){
    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = this.input.keyboard.addKeys('W,A,S,D');
    this.joy = {x:0,y:0,active:false};
    const zone=document.getElementById('stickZone');
    const base=document.getElementById('stickBase');
    const knob=document.getElementById('stickKnob');
    let pointer=null, center={x:0,y:0}, radius=1;
    const refresh=()=>{const r=base.getBoundingClientRect();center={x:r.left+r.width/2,y:r.top+r.height/2};radius=r.width*.36;};
    const set=(e)=>{const dx=e.clientX-center.x,dy=e.clientY-center.y,n=Math.hypot(dx,dy)||1,m=Math.min(n,radius),mx=dx/n*m,my=dy/n*m;this.joy.x=mx/radius;this.joy.y=my/radius;this.joy.active=true;knob.style.left=`calc(29% + ${mx}px)`;knob.style.top=`calc(29% + ${my}px)`;};
    const clear=()=>{pointer=null;this.joy.x=this.joy.y=0;this.joy.active=false;knob.style.left='29%';knob.style.top='29%';};
    zone.addEventListener('pointerdown',e=>{refresh();pointer=e.pointerId;zone.setPointerCapture?.(pointer);set(e);e.preventDefault();});
    zone.addEventListener('pointermove',e=>{if(pointer===e.pointerId)set(e)});
    zone.addEventListener('pointerup',e=>{if(pointer===e.pointerId)clear()});
    zone.addEventListener('pointercancel',clear);
  }

  createRain(){
    this.rain=[];
    // v6 deliberately restores a much more visible rain layer.
    const count = innerWidth < 700 ? 120 : 190;
    for(let i=0;i<count;i++){
      const near = Math.random() < .22;
      const x=Math.random()*this.W;
      const y=380+Math.random()*570;
      const drop=this.add.rectangle(x,y,near?2:1,near?10:7,0xc7c6df,near?.50:(.28+Math.random()*.20))
        .setDepth(near?9995:9980).setAngle(10);
      this.rain.push({drop,speed:(near?250:175)+Math.random()*100,drift:-32-Math.random()*18,near});
    }
  }

  drawDesignDebug(){
    const g=this.add.graphics().setDepth(99999);
    const draw=(list,color)=>{g.lineStyle(2,color,.95);for(const b of list){g.strokeRect(b.x-b.w/2,b.y-b.h/2,b.w,b.h);}};
    draw(this.cfg.buildingHitboxes,0xff3344);
    draw(this.cfg.propHitboxes,0xffaa00);
    draw(this.cfg.barriers,0xff00ff);
    g.lineStyle(2,0x00ff88,.95);
    g.strokeRect(this.cfg.player.spawn.x-this.cfg.player.bodyWidth/2,this.cfg.player.spawn.y-this.cfg.player.bodyHeight/2,this.cfg.player.bodyWidth,this.cfg.player.bodyHeight);
    g.lineStyle(1,0x44ffcc,.65);
    g.strokeRect(0,this.cfg.world.playTop,this.W,this.cfg.world.playBottom-this.cfg.world.playTop);
  }

  getAxis(){
    let x=this.joy.x,y=this.joy.y;
    if(this.keys.A.isDown||this.cursors.left.isDown)x-=1;
    if(this.keys.D.isDown||this.cursors.right.isDown)x+=1;
    if(this.keys.W.isDown||this.cursors.up.isDown)y-=1;
    if(this.keys.S.isDown||this.cursors.down.isDown)y+=1;
    const m=Math.hypot(x,y);
    if(m>1){x/=m;y/=m;}
    if(m<.18 && this.joy.active) return {x:0,y:0};
    return {x,y};
  }

  makeContactRipple(x,y,color=0xa9a5c8,alpha=.24){
    const e=this.add.ellipse(x,y+3,20,7).setStrokeStyle(1,color,alpha).setFillStyle(0x000000,0).setDepth(y-1);
    this.tweens.add({targets:e,scaleX:1.8,scaleY:1.8,alpha:0,duration:320,ease:'Quad.Out',onComplete:()=>e.destroy()});
  }

  makeStepReaction(){
    const x=this.playerBody.x,y=this.playerBody.y;
    this.makeContactRipple(x,y,0xb8b4d4,.18);
    if(Math.random()<.55){
      const leaf=this.add.rectangle(x+(Math.random()-.5)*18,y+(Math.random()-.5)*8,4,2,Math.random()<.5?0x8a4056:0xa35062,.75).setDepth(y+2).setAngle(Math.random()*180);
      this.tweens.add({targets:leaf,x:leaf.x+(Math.random()-.5)*24,y:leaf.y-9-Math.random()*9,angle:leaf.angle+100,alpha:0,duration:460,onComplete:()=>leaf.destroy()});
    }
  }

  updateRain(dt){
    const minY=360,maxY=970;
    for(const r of this.rain){
      r.drop.y+=r.speed*dt;
      r.drop.x+=r.drift*dt;
      if(r.drop.y>maxY){r.drop.y=minY-Math.random()*90;r.drop.x=Math.random()*this.W;}
      if(r.drop.x<0)r.drop.x=this.W;
    }
  }

  update(time,delta){
    const dt=Math.min(.033,delta/1000);
    const a=this.getAxis();
    const moving=Math.abs(a.x)+Math.abs(a.y)>.02;
    const targetX=moving?a.x*this.speed:0;
    const targetY=moving?a.y*this.speed:0;
    const blend=1-Math.exp(-this.cfg.player.acceleration*dt);
    this.velocity.x=Phaser.Math.Linear(this.velocity.x,targetX,blend);
    this.velocity.y=Phaser.Math.Linear(this.velocity.y,targetY,blend);
    if(!moving && Math.hypot(this.velocity.x,this.velocity.y)<.35)this.velocity.set(0,0);
    this.playerBody.body.setVelocity(this.velocity.x,this.velocity.y);

    // Redundant safety clamp: Arcade bounds are authoritative, but this prevents any
    // numerical edge case from ever letting her disappear off the designed play strip.
    const safeX=Phaser.Math.Clamp(this.playerBody.x,14,this.W-14);
    const safeY=Phaser.Math.Clamp(this.playerBody.y,this.cfg.world.playTop+8,this.cfg.world.playBottom-12);
    if(safeX!==this.playerBody.x||safeY!==this.playerBody.y){
      this.playerBody.setPosition(safeX,safeY);
      this.playerBody.body.setVelocity(0,0);
      this.velocity.set(0,0);
    }

    if(moving){
      if(Math.abs(a.x)>Math.abs(a.y))this.direction=a.x<0?'left':'right'; else this.direction=a.y<0?'up':'down';
      this.animClock+=dt*(1.8+Math.hypot(this.velocity.x,this.velocity.y)/this.speed*2.4);
      this.stepClock+=dt;
      if(this.stepClock>.48){this.stepClock=0;this.makeStepReaction();}
    } else {
      this.animClock=0;
      this.stepClock=.20;
    }

    const frame=moving?WALK[Math.floor(this.animClock)%WALK.length]:0;
    const atlasFrame=DIR_ROW[this.direction]*4+frame;
    this.player.setFrame(atlasFrame);
    this.warmOverlay.setFrame(atlasFrame);
    this.reflection.setFrame(atlasFrame);

    const x=this.playerBody.x,y=this.playerBody.y;
    const bob=moving?Math.sin(this.animClock*Math.PI)*.8:0;
    this.player.setPosition(x,y-bob).setDepth(y);
    this.warmOverlay.setPosition(x,y-bob).setDepth(y+.02);
    this.reflection.setPosition(x,y+6).setDepth(y-20);

    let warm=0,nearest=null,nearestD=Infinity;
    for(const l of this.cfg.warmLights){
      const d=Math.hypot(x-l.x,y-l.y);
      const t=Math.max(0,1-d/l.radius);
      warm=Math.max(warm,t*l.strength);
      if(d<nearestD){nearestD=d;nearest=l;}
    }
    this.warmOverlay.setAlpha(Math.min(.24,warm));
    this.reflection.setAlpha(.08+warm*.34);

    let sx=0,sy=0;
    if(nearest){
      const dx=x-nearest.x,dy=y-nearest.y,m=Math.hypot(dx,dy)||1;
      sx=dx/m*(4+warm*20);sy=dy/m*(1.5+warm*7);
    }
    this.shadow.setPosition(x+sx,y+2+sy).setScale(1+warm*.30,1-warm*.10).setAlpha(.37-warm*.07).setDepth(y-2);

    this.updateRain(dt);
  }
}

const config={
  type:Phaser.WEBGL,
  parent:'game',
  width:innerWidth,
  height:innerHeight,
  backgroundColor:'#120f1f',
  pixelArt:true,
  antialias:false,
  roundPixels:true,
  scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},
  physics:{
    default:'arcade',
    arcade:{gravity:{x:0,y:0},debug:DEBUG,debugShowBody:DEBUG,debugBodyColor:0x00ff66,debugStaticBodyColor:0xff3355}
  },
  scene:[StreetScene]
};
new Phaser.Game(config);
})();
