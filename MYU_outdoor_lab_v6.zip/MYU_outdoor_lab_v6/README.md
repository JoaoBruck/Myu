# MYU — Outdoor Engine Lab v6

Esta versão corrige os três problemas reportados no celular: velocidade, desaparecimento e chuva pouco visível.

## JavaScript / Phaser
O site continua em **JavaScript**, com Phaser 4.2.1 e WebGL. Nesta build a movimentação foi trocada de Matter para **Arcade Physics**, porque o movimento top-down precisa de velocidade previsível em pixels por segundo e colisores estáticos simples e confiáveis.

## Movimento
- velocidade máxima: **32 px/s**;
- aceleração/desaceleração mais lentas;
- animação de caminhada desacelerada para acompanhar a velocidade;
- corpo físico: retângulo de 18×10 px apenas nos pés;
- world bounds físicos + clamp de segurança.

## Física do cenário
- fachada do prédio agora é uma cadeia contínua de cinco colisores estáticos sem abertura entre eles;
- banco, placa, vaso, balizadores, poste, jardineira e placas da direita permanecem físicos;
- borda sul e corrimão continuam bloqueados;
- `?debug=1` mostra todas as caixas.

## Correção do desaparecimento
Os recortes de foreground anteriores eram quase retângulos opacos inteiros e podiam esconder a protagonista. Eles foram mascarados para manter apenas as regiões dos objetos que realmente devem passar na frente da personagem.

## Chuva
- 120 gotas no mobile / 190 no desktop;
- maior contraste e alpha;
- gotas mais longas;
- camada próxima e camada distante;
- velocidade e drift maiores para recuperar a leitura de chuva forte.

## Debug
`?debug=1`
