# MYU — 17:40 v10

- novo interior do café integrado ao jogo;
- cenário externo preservado;
- colisões próprias para cada cenário;
- transição rua ↔ café;
- câmera afastada com dead zone;
- controles mobile;
- animação de caminhada + idle;
- sem o sistema antigo de oclusão por recortes que cortava a personagem.
