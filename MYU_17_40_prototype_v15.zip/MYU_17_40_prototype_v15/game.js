const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha: false });
ctx.imageSmoothingEnabled = false;
const hud = document.getElementById('hud');
const pill = document.getElementById('pill');
const actionBtn = document.getElementById('actionBtn');
const actionLabel = actionBtn.querySelector('small');
const dialogueEl = document.getElementById('dialogue');
const dialogueText = document.getElementById('dialogueText');
const dialogueTag = document.getElementById('dialogueTag');

let data, current = 'exterior', mask, last = 0, fade = 0, transition = null, hudTimer = 0;
const assets = {}, masks = {}, keys = {}, input = { x: 0, y: 0 };
const player = { x: 0, y: 0, vx: 0, vy: 0, dir: 'front', moving: false, anim: 0, idle: 0 };
const cam = { x: 0, y: 0, zoom: 1 };
const dialogue = { open: false, lines: [], index: 0, speaker: 'MYU // 17:40' };
const npcState = new Map();

const WALK = [0, 1, 2, 3, 2, 1];
const OFFSETS = {
  front: [[0, 0], [0, -1], [0, 0], [0, 1]],
  back: [[0, 0], [0, -1], [0, 0], [0, 1]],
  left: [[0, 0], [-1, 0], [0, -1], [1, 0]],
  right: [[0, 0], [1, 0], [0, -1], [-1, 0]]
};

const dpr = () => Math.max(1, devicePixelRatio || 1);
const sc = () => data.scenes[current];
function status() {
  return current === 'exterior'
    ? 'Explore a rua e entre no café quando quiser.'
    : 'Observe o interior. A perto da porta volta para a rua.';
}
function showHUD(text, t = 1.6) {
  pill.textContent = text;
  hud.classList.remove('hidden');
  hudTimer = t;
}
async function img(src) {
  if (assets[src]) return assets[src];
  const im = new Image();
  await new Promise((resolve, reject) => {
    im.onload = resolve;
    im.onerror = reject;
    im.src = src;
  });
  return (assets[src] = im);
}

async function boot() {
  data = await fetch('data/scene.json?v=15').then(r => r.json());
  const files = new Set([data.atlas.file, data.atlas.shadow.file]);
  for (const s of Object.values(data.scenes)) {
    files.add(s.bg);
    files.add(s.collision);
    for (const npc of (s.npcs || [])) files.add(npc.file);
  }
  await Promise.all([...files].map(img));
  switchScene('exterior', data.scenes.exterior.start, true);
  resize();
  showHUD(status(), 2.6);
  requestAnimationFrame(loop);
}

function makeMask(src) {
  const im = assets[src];
  const c = document.createElement('canvas');
  c.width = im.width;
  c.height = im.height;
  const x = c.getContext('2d');
  x.drawImage(im, 0, 0);
  return { w: c.width, h: c.height, p: x.getImageData(0, 0, c.width, c.height).data };
}
function getMask(src) {
  return masks[src] || (masks[src] = makeMask(src));
}

function switchScene(name, spawn, instant = false) {
  current = name;
  player.x = spawn.x;
  player.y = spawn.y;
  player.vx = 0;
  player.vy = 0;
  player.dir = spawn.dir || 'front';
  player.anim = 0;
  player.idle = 0;
  mask = getMask(sc().collision);
  if (instant) {
    cam.x = player.x;
    cam.y = player.y;
  }
  showHUD(status(), 1.5);
}

function resize() {
  canvas.width = Math.floor(innerWidth * dpr());
  canvas.height = Math.floor(innerHeight * dpr());
  canvas.style.width = innerWidth + 'px';
  canvas.style.height = innerHeight + 'px';
  ctx.imageSmoothingEnabled = false;
  if (data) {
    const b = assets[sc().bg];
    const fit = Math.max(canvas.width / b.width, canvas.height / b.height);
    cam.zoom = fit * 0.8;
  }
  refreshStick();
}
addEventListener('resize', resize);

function pointWalkable(x, y) {
  if (!mask) return false;
  const px = Math.round(x), py = Math.round(y);
  if (px < 0 || py < 0 || px >= mask.w || py >= mask.h) return false;
  const i = (py * mask.w + px) * 4;
  return mask.p[i] >= 128;
}

function hitBlocker(x, y, b, r = 5) {
  if (b.type === 'rect') return x + r > b.x && x - r < b.x + b.w && y + r > b.y && y - r < b.y + b.h;
  if (b.type === 'ellipse') {
    const dx = x - b.x;
    const dy = y - b.y;
    const rx = b.rx + r;
    const ry = b.ry + r;
    return (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) <= 1;
  }
  return false;
}
function blockedByScene(x, y) {
  const blockers = sc().blockers || [];
  const probes = [[0, 0], [5, 0], [-5, 0], [0, 4], [0, -4], [3, 3], [-3, 3]];
  for (const [ox, oy] of probes) {
    const px = x + ox, py = y + oy;
    for (const b of blockers) if (hitBlocker(px, py, b)) return true;
  }
  return false;
}
function blockedByNPCs(x, y) {
  for (const npc of (sc().npcs || [])) {
    const r = (npc.radius || 24) + 7;
    const dx = x - npc.x, dy = y - npc.y;
    if (dx * dx + dy * dy < r * r) return true;
  }
  return false;
}
function walkable(x, y) {
  const pts = [[0, 0], [5, 0], [-5, 0], [0, 4], [0, -4], [4, 4], [-4, 4], [4, -4], [-4, -4]];
  for (const [ox, oy] of pts) if (!pointWalkable(x + ox, y + oy)) return false;
  return !blockedByScene(x, y) && !blockedByNPCs(x, y);
}

function openDialogue(lines, speaker = 'MYU // 17:40') {
  dialogue.lines = Array.isArray(lines) ? lines : [String(lines)];
  dialogue.speaker = speaker;
  dialogue.index = 0;
  dialogue.open = true;
  dialogueTag.textContent = dialogue.speaker;
  dialogueText.textContent = dialogue.lines[0] || '';
  dialogueEl.classList.remove('hidden');
  actionLabel.textContent = 'seguir';
}
function closeDialogue() {
  dialogue.open = false;
  dialogueEl.classList.add('hidden');
}
function nextDialogue() {
  if (!dialogue.open) return false;
  if (dialogue.index < dialogue.lines.length - 1) {
    dialogue.index += 1;
    dialogueText.textContent = dialogue.lines[dialogue.index];
  } else {
    closeDialogue();
  }
  return true;
}

function nearDoor() {
  const d = sc().door;
  return Math.hypot(player.x - d.x, player.y - d.y) < d.radius;
}
function nearestInteraction() {
  const list = sc().interactives || [];
  let best = null;
  let bestDist = Infinity;
  for (const item of list) {
    const dist = Math.hypot(player.x - item.x, player.y - item.y);
    if (dist < item.radius && dist < bestDist) {
      best = item;
      bestDist = dist;
    }
  }
  return best;
}
function nearestNpc() {
  let best = null;
  let bestDist = Infinity;
  for (const npc of (sc().npcs || [])) {
    const dist = Math.hypot(player.x - npc.x, player.y - npc.y);
    if (dist < (npc.interactRadius || 88) && dist < bestDist) {
      best = npc;
      bestDist = dist;
    }
  }
  return best;
}
function npcDialogue(npc) {
  const seen = npcState.get(npc.id) || 0;
  npcState.set(npc.id, seen + 1);
  return seen === 0 ? npc.firstDialogue : (npc.repeatDialogue || npc.firstDialogue);
}
function actionWord() {
  if (dialogue.open) return 'seguir';
  if (nearDoor()) return current === 'exterior' ? 'entrar' : 'sair';
  const npc = nearestNpc();
  if (npc) return npc.label || 'conversar';
  const item = nearestInteraction();
  return item ? (item.label || 'ver') : 'agir';
}

addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  keys[k] = true;
  if (['e', ' ', 'enter'].includes(k)) {
    e.preventDefault();
    interact();
  }
});
addEventListener('keyup', e => (keys[e.key.toLowerCase()] = false));

function axis() {
  let x = input.x, y = input.y;
  const kx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0);
  const ky = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0);
  if (kx || ky) { x = kx; y = ky; }
  let n = Math.hypot(x, y);
  if (n > 1) { x /= n; y /= n; n = 1; }
  if (!(kx || ky)) {
    const dz = 0.18;
    if (n < dz) return { x: 0, y: 0 };
    const t = (n - dz) / (1 - dz);
    const c = t * t * (3 - 2 * t);
    x = (x / n) * c;
    y = (y / n) * c;
  }
  return { x, y };
}

const stickZone = document.getElementById('stickZone');
const stickBase = document.getElementById('stickBase');
const knob = document.getElementById('stickKnob');
let dragging = false, center = { x: 0, y: 0 }, radius = 1;
function refreshStick() {
  const r = stickBase.getBoundingClientRect();
  center = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  radius = r.width * 0.36;
}
function setStick(x, y) {
  const dx = x - center.x, dy = y - center.y;
  const n = Math.hypot(dx, dy) || 1;
  const m = Math.min(n, radius);
  const mx = (dx / n) * m, my = (dy / n) * m;
  input.x = mx / radius;
  input.y = my / radius;
  knob.style.left = `calc(29% + ${mx}px)`;
  knob.style.top = `calc(29% + ${my}px)`;
}
function clearStick() {
  dragging = false;
  input.x = 0;
  input.y = 0;
  knob.style.left = '29%';
  knob.style.top = '29%';
}
stickZone.addEventListener('pointerdown', e => { refreshStick(); dragging = true; setStick(e.clientX, e.clientY); e.preventDefault(); });
addEventListener('pointermove', e => dragging && setStick(e.clientX, e.clientY));
addEventListener('pointerup', () => dragging && clearStick());
addEventListener('pointercancel', () => dragging && clearStick());
actionBtn.addEventListener('pointerdown', () => { navigator.vibrate?.(9); interact(); });

function interact() {
  if (dialogue.open) return void nextDialogue();
  if (transition) return;
  if (nearDoor()) {
    const d = sc().door;
    transition = { to: d.to, spawn: d.spawn, phase: 'out' };
    return;
  }
  const npc = nearestNpc();
  if (npc) return void openDialogue(npcDialogue(npc), npc.name || '...');
  const item = nearestInteraction();
  if (item) return void openDialogue(item.text);
  showHUD('Nada chama sua atenção por aqui.', 0.9);
}

function update(dt) {
  if (hudTimer > 0) {
    hudTimer -= dt;
    if (hudTimer <= 0) hud.classList.add('hidden');
  }

  const actionable = dialogue.open || nearDoor() || !!nearestNpc() || !!nearestInteraction();
  actionBtn.classList.toggle('near', actionable);
  actionLabel.textContent = actionWord();

  if (transition) {
    const s = 7;
    if (transition.phase === 'out') {
      fade = Math.min(1, fade + dt * s);
      player.vx *= 0.72;
      player.vy *= 0.72;
      if (fade >= 1) {
        switchScene(transition.to, transition.spawn);
        transition.phase = 'in';
      }
    } else {
      fade = Math.max(0, fade - dt * s);
      if (fade <= 0) transition = null;
    }
  }

  const a = dialogue.open ? { x: 0, y: 0 } : axis();
  const max = current === 'exterior' ? 152 : 140;
  const targetX = transition ? 0 : a.x * max;
  const targetY = transition ? 0 : a.y * max;
  const active = Math.abs(a.x) + Math.abs(a.y) > 0.01;

  player.vx += (targetX - player.vx) * Math.min(1, dt * (active ? 11.5 : 8));
  player.vy += (targetY - player.vy) * Math.min(1, dt * (active ? 11.5 : 8));

  const sp = Math.hypot(player.vx, player.vy);
  player.moving = sp > 4;
  if (player.moving) {
    player.dir = Math.abs(player.vx) > Math.abs(player.vy)
      ? (player.vx > 0 ? 'right' : 'left')
      : (player.vy > 0 ? 'front' : 'back');
    player.anim = (player.anim + dt * (2.5 + (sp / max) * 3.6)) % WALK.length;
    player.idle = 0;
  } else {
    player.anim = 0;
    player.idle += dt;
  }

  const nx = player.x + player.vx * dt;
  const ny = player.y + player.vy * dt;
  if (walkable(nx, player.y)) player.x = nx; else player.vx = 0;
  if (walkable(player.x, ny)) player.y = ny; else player.vy = 0;

  const b = assets[sc().bg];
  const vw = canvas.width / cam.zoom;
  const vh = canvas.height / cam.zoom;
  const dx = player.x - cam.x;
  const dy = player.y - cam.y;
  const dzx = vw * 0.11;
  const dzy = vh * 0.09;

  let tx = cam.x, ty = cam.y;
  if (dx > dzx) tx = player.x - dzx; else if (dx < -dzx) tx = player.x + dzx;
  if (dy > dzy) ty = player.y - dzy; else if (dy < -dzy) ty = player.y + dzy;
  tx = Math.max(vw / 2, Math.min(b.width - vw / 2, tx));
  ty = Math.max(vh / 2, Math.min(b.height - vh / 2, ty));
  cam.x += (tx - cam.x) * Math.min(1, dt * 6);
  cam.y += (ty - cam.y) * Math.min(1, dt * 6);
}

function drawShadow(x, y, frame, depth, dir, alpha = 0.72) {
  const shadowAtlas = assets[data.atlas.shadow.file];
  const sw = 44 * depth, sh = 16 * depth;
  const shadowXOffset = dir === 'right' ? 2 : dir === 'left' ? -2 : 0;
  ctx.globalAlpha = alpha;
  ctx.drawImage(shadowAtlas, frame * data.atlas.shadow.frameW, 0, data.atlas.shadow.frameW, data.atlas.shadow.frameH,
    x - sw / 2 + shadowXOffset, y - sh / 2 - 4, sw, sh);
  ctx.globalAlpha = 1;
}
function drawNpc(npc, t) {
  const atlas = assets[npc.file];
  const frame = Math.floor(t * (npc.fps || 1.5)) % (npc.frames || 2);
  const fw = npc.frameW, fh = npc.frameH;
  const row = npc.rows[npc.dir || 'front'];
  const depth = 0.985 + (npc.y / assets[sc().bg].height) * 0.06;
  const scale = (npc.scale || 1) * depth;
  const dw = fw * scale, dh = fh * scale;
  drawShadow(npc.x, npc.y, frame, depth * 0.93, npc.dir || 'front', 0.46);
  ctx.drawImage(atlas, frame * fw, row * fh, fw, fh, npc.x - dw / 2, npc.y - dh + 7, dw, dh);
}
function drawPlayerActor() {
  const b = assets[sc().bg];
  const atlas = assets[data.atlas.file];
  const row = data.atlas.rows[player.dir];
  const fw = data.atlas.frameW, fh = data.atlas.frameH;
  const frame = player.moving ? WALK[Math.floor(player.anim) % WALK.length] % 4 : 0;
  const depth = current === 'exterior' ? 1 + (player.y / b.height) * 0.09 : 0.985 + (player.y / b.height) * 0.06;
  const move = Math.min(1, Math.hypot(player.vx, player.vy) / (current === 'exterior' ? 152 : 140));
  const bob = player.moving ? Math.sin((player.anim / WALK.length) * Math.PI * 2) * 1.4 * move : Math.sin(player.idle * 1.8) * 0.35;
  const breathe = player.moving ? 0 : Math.sin(player.idle * 2.1) * 0.006;
  const scale = data.atlas.scale * depth;
  const dw = fw * scale * (1 - breathe), dh = fh * scale * (1 + breathe);
  const off = OFFSETS[player.dir][frame] || [0, 0];
  drawShadow(player.x, player.y, frame, depth, player.dir, current === 'exterior' ? 0.82 : 0.72);
  ctx.drawImage(atlas, frame * fw, row * fh, fw, fh, player.x - dw / 2 + off[0], player.y - dh + 8 + off[1] - bob, dw, dh);
}
function draw() {
  const s = sc();
  const b = assets[s.bg];
  ctx.fillStyle = '#120f1f';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  const vw = canvas.width / cam.zoom;
  const vh = canvas.height / cam.zoom;
  const cx = Math.max(vw / 2, Math.min(b.width - vw / 2, cam.x));
  const cy = Math.max(vh / 2, Math.min(b.height - vh / 2, cam.y));
  const sx = cx - vw / 2;
  const sy = cy - vh / 2;

  ctx.save();
  ctx.scale(cam.zoom, cam.zoom);
  ctx.translate(-sx, -sy);
  ctx.drawImage(b, 0, 0);

  const actors = [
    ...((sc().npcs || []).map(npc => ({ y: npc.y, kind: 'npc', npc }))),
    { y: player.y, kind: 'player' }
  ].sort((a, b) => a.y - b.y);
  const t = performance.now() / 1000;
  for (const actor of actors) {
    if (actor.kind === 'npc') drawNpc(actor.npc, t);
    else drawPlayerActor();
  }
  ctx.restore();

  if (fade > 0) {
    ctx.fillStyle = `rgba(9,7,16,${fade})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
}

function loop(t) {
  if (!last) last = t;
  const dt = Math.min(0.033, (t - last) / 1000);
  last = t;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}

boot();
