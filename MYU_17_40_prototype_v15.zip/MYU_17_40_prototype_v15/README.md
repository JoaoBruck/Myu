# MYU 17:40 Prototype v15

## Nesta versão
- Primeiro NPC funcional dentro do café: **Atendente**.
- Sprite próprio em pixel art com 4 direções e 2 frames de idle.
- NPC possui colisão própria: a personagem não atravessa o corpo dele.
- Interação contextual: o botão A muda para **conversar** quando a personagem se aproxima.
- Diálogo com nome do NPC e falas diferentes na primeira conversa e nas repetições.
- Sistema de atores com ordenação por profundidade (player/NPC por eixo Y).
- Estrutura de áudio preparada em `data/audio.json` e `assets/audio/`.

## Arquivos de áudio esperados
- `17_40_exterior.ogg`
- `17_40_cafe.ogg`
- `rain_loop.ogg`
- `door_bell.ogg`
- `step_stone_1.ogg`
- `step_stone_2.ogg`
- `step_wood_1.ogg`
- `step_wood_2.ogg`
- `dialogue_tick.ogg`

O áudio permanece desabilitado até que os arquivos sejam colocados na pasta e `data/audio.json` seja alterado para `"enabled": true`.

## Testes executados
1. Todos os assets necessários presentes.
2. Dimensões do atlas do NPC conferidas.
3. Caminho válido da entrada até a área de conversa com o NPC.
4. Colisão física do NPC funcionando.
5. Diálogo inicial e diálogo repetido configurados.

Todos os cinco testes passaram.
