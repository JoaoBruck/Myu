# MYU — Outdoor Engine Lab v1

Foco desta build: **somente a rua 17:40**. A cafeteria foi retirada do escopo por enquanto.

## Base técnica
- Phaser 4.2.1 via WebGL
- Matter Physics
- normal maps para personagem e ambiente
- iluminação dinâmica Phaser 4
- self-shadow na personagem em qualidade alta
- depth sorting por `y`
- foreground overlays extraídos do próprio cenário para o personagem passar atrás / na frente de objetos corretamente
- hitbox física apenas nos pés da personagem
- chuva e reflexos molhados procedurais
- joystick mobile

## Mudanças que atacam os bugs antigos
- personagem passou de ~60 px para ~155–168 px de altura visual no mundo
- colisões não usam mais grandes retângulos invisíveis atravessando áreas abertas
- limites físicos seguem o perímetro caminhável da calçada
- postes, placa, banco, vasos e balizadores têm corpos físicos próprios
- oclusão não é mais `background + personagem`; objetos importantes possuem foreground independente com `depth` ancorado no pé do objeto

## Debug
Adicione `?debug=1` à URL para ver as colisões do Matter e o contorno da área caminhável.

## Qualidade
- `?quality=high` — iluminação + self-shadow + mais chuva
- `?quality=medium`
- `?quality=low`
