(() => {
'use strict';

const DEBUG = new URLSearchParams(location.search).get('debug') === '1';
const QUALITY = new URLSearchParams(location.search).get('quality') || 'high';
const input = { x: 0, y: 0, action: false };
window.MYU_INPUT = input;

// HTML virtual stick
const stickZone = document.getElementById('stickZone');
const stickBase = document.getElementById('stickBase');
const knob = document.getElementById('stickKnob');
const actionBtn = document.getElementById('actionBtn');
let dragging = false, center = {x:0,y:0}, radius = 1;
function refreshStick(){
  const r = stickBase.getBoundingClientRect();
  center = {x:r.left+r.width/2,y:r.top+r.height/2};
  radius = r.width * .36;
}
function setStick(x,y){
  const dx=x-center.x,dy=y-center.y,n=Math.hypot(dx,dy)||1,m=Math.min(n,radius);
  const mx=dx/n*m,my=dy/n*m;
  input.x=mx/radius; input.y=my/radius;
  knob.style.left=`calc(29% + ${mx}px)`;
  knob.style.top=`calc(29% + ${my}px)`;
}
function clearStick(){dragging=false;input.x=input.y=0;knob.style.left='29%';knob.style.top='29%'}
stickZone.addEventListener('pointerdown',e=>{refreshStick();dragging=true;stickZone.setPointerCapture?.(e.pointerId);setStick(e.clientX,e.clientY);e.preventDefault()});
stickZone.addEventListener('pointermove',e=>dragging&&setStick(e.clientX,e.clientY));
stickZone.addEventListener('pointerup',clearStick);stickZone.addEventListener('pointercancel',clearStick);
actionBtn.addEventListener('pointerdown',e=>{e.preventDefault();input.action=true;navigator.vibrate?.(8)});
addEventListener('resize',refreshStick,{passive:true});

class StreetLab extends Phaser.Scene {
  constructor(){ super('StreetLab'); }

  preload(){
    this.load.image('street', ['assets/backgrounds/exterior.webp','assets/backgrounds/exterior_normal.png']);
    this.load.spritesheet('witch', ['assets/sprites/witch_walk_atlas.webp','assets/sprites/witch_walk_normal.png'], { frameWidth:184, frameHeight:316 });
    this.load.image('shadow', 'assets/sprites/shadow_atlas.png');
    this.load.json('world', 'data/world.json');
    this.load.json('foregroundData', 'data/foreground.json');
    for (const id of ['bench','bollard1','bollard2','bollard3','bollard4','bollard5','signboard','lamp','planter','signs']) {
      this.load.image('fg_'+id, 'assets/foreground/'+id+'.png');
    }
  }

  create(){
    this.worldData = this.cache.json.get('world');
    this.keys = this.input.keyboard?.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,SPACE,ENTER,E') || {};

    // World and baked art
    this.street = this.add.image(0,0,'street').setOrigin(0).setDepth(0);
    if (this.street.setLighting) this.street.setLighting(true);
    this.matter.world.setBounds(-40,-40,1528,1166,64,true,true,true,true);

    // Matter collision: a visible walkable polygon with physical edges only where the art has a curb / wall.
    this.makeBoundary(this.worldData.walkBoundary);
    this.makeObstacles(this.worldData.obstacles);

    // Player foot body is independent from the visual sprite. This keeps collisions at the feet instead of around her hair/coat.
    const s = this.worldData.spawn;
    this.playerBody = this.matter.add.rectangle(s.x,s.y,30,16,{label:'PLAYER_FEET',friction:0,frictionStatic:0,frictionAir:.18,restitution:0});
    this.playerBody.inertia = Infinity; this.playerBody.inverseInertia = 0;
    this.playerBody.angle = 0; this.playerBody.angularVelocity = 0;

    this.player = this.add.sprite(s.x,s.y,'witch',0)
      .setOrigin(.5,.91)
      .setScale(.51)
      .setDepth(s.y);
    if (this.player.setLighting) this.player.setLighting(true);
    if (this.player.setSelfShadow) this.player.setSelfShadow(QUALITY==='high', .55, .28);

    this.shadow = this.add.ellipse(s.x,s.y+2,52,17,0x17121f,.36).setDepth(s.y-.5);
    this.shadow.setBlendMode(Phaser.BlendModes.MULTIPLY);

    this.foregrounds = [];
    for (const o of this.cache.json.get('foregroundData')) {
      const fg = this.add.image(o.x,o.y,'fg_'+o.id).setOrigin(0).setDepth(o.footY);
      this.foregrounds.push({ ...o, sprite:fg });
    }

    // Dynamic 17:40 lighting. Flat normal on environment, relief normal on player.
    this.lights.enable();
    this.lights.setAmbientColor(0x70778d);
    this.lightObjects = this.worldData.lights.map(l => {
      const light = this.lights.addLight(l.x,l.y,l.radius,Number(l.color),l.intensity,l.z);
      return { config:l, light };
    });

    // Warm reflection veil on wet stone, intentionally below the character.
    this.reflectionGfx = this.add.graphics().setDepth(60).setBlendMode(Phaser.BlendModes.ADD);
    this.rainGfx = this.add.graphics().setDepth(2000).setBlendMode(Phaser.BlendModes.SCREEN);
    this.rain = this.makeRain(QUALITY==='high'?150:QUALITY==='medium'?90:45);

    // Camera framing: a portrait phone sees roughly 500px of world width, matching the approved 17:40 composition.
    this.cameras.main.setBounds(0,0,1448,1086);
    this.cameras.main.startFollow(this.player,false,.09,.09);
    this.cameras.main.setDeadzone(120,90);
    this.applyZoom();
    this.scale.on('resize',()=>this.applyZoom());

    if (DEBUG) this.makeDebug();

    this.walkClock=0;
    this.observationShown=false;
  }

  applyZoom(){
    const cam=this.cameras.main;
    const viewportW=this.scale.width, viewportH=this.scale.height;
    const fit=Math.max(viewportW/1448, viewportH/1086);
    cam.setZoom(Math.max(.72, Math.min(1.28, fit*1.02)));
  }

  makeBoundary(points){
    for(let i=0;i<points.length;i++){
      const a=points[i], b=points[(i+1)%points.length];
      const dx=b[0]-a[0],dy=b[1]-a[1];
      const len=Math.hypot(dx,dy),angle=Math.atan2(dy,dx);
      this.matter.add.rectangle((a[0]+b[0])/2,(a[1]+b[1])/2,len,18,{isStatic:true,angle,label:'WALK_EDGE'});
    }
  }

  makeObstacles(list){
    for(const o of list){
      if(o.type==='rect') this.matter.add.rectangle(o.x,o.y,o.w,o.h,{isStatic:true,label:o.id});
      else this.matter.add.circle(o.x,o.y,o.r,{isStatic:true,label:o.id});
    }
  }

  makeRain(count){
    return Array.from({length:count},(_,i)=>({
      x:(i*97)%1448,
      y:(i*173)%1086,
      speed:330+(i%7)*24,
      len:8+(i%4)*3,
      drift:-55+(i%5)*5,
      alpha:.10+(i%6)*.018
    }));
  }

  makeDebug(){
    const g=this.add.graphics().setDepth(9999);
    g.lineStyle(3,0x44ff88,.9);
    const p=this.worldData.walkBoundary;
    g.beginPath();g.moveTo(p[0][0],p[0][1]);for(let i=1;i<p.length;i++)g.lineTo(p[i][0],p[i][1]);g.closePath();g.strokePath();
    g.lineStyle(2,0xff4d7a,.9);
    for(const o of this.worldData.obstacles){
      if(o.type==='rect') g.strokeRect(o.x-o.w/2,o.y-o.h/2,o.w,o.h);
      else g.strokeCircle(o.x,o.y,o.r);
    }
  }

  keyboardAxis(){
    let x=input.x,y=input.y;
    const K=this.keys;
    const down=k=>k?.isDown;
    if(down(K.A)||down(K.LEFT))x-=1;if(down(K.D)||down(K.RIGHT))x+=1;
    if(down(K.W)||down(K.UP))y-=1;if(down(K.S)||down(K.DOWN))y+=1;
    const n=Math.hypot(x,y);if(n>1){x/=n;y/=n}
    return{x,y};
  }

  nearestLight(px,py){
    let best=this.lightObjects[0],dist=Infinity;
    for(const o of this.lightObjects){const d=Math.hypot(px-o.config.x,py-o.config.y);if(d<dist){dist=d;best=o}}
    return { ...best, dist };
  }

  update(time,delta){
    const dt=Math.min(delta/1000,.034);
    const a=this.keyboardAxis();
    const speed=145;
    this.matter.setVelocity(this.playerBody,a.x*speed,a.y*speed);
    this.playerBody.angle=0; this.playerBody.angularVelocity=0;

    const px=this.playerBody.position.x,py=this.playerBody.position.y;
    const moving=Math.hypot(a.x,a.y)>.05;
    if(moving){
      if(Math.abs(a.x)>Math.abs(a.y)) this.dir=a.x<0?'left':'right'; else this.dir=a.y<0?'back':'front';
      this.walkClock+=dt*7.4;
    } else this.walkClock=0;
    const rows={front:0,left:1,right:2,back:3};
    const seq=[0,1,2,3,2,1];
    const frame=(rows[this.dir||'front']*4)+(moving?seq[Math.floor(this.walkClock)%seq.length]:0);
    this.player.setFrame(frame);
    const perspectiveScale = .49 + Phaser.Math.Clamp((py-480)/420, 0, 1) * .045;
    this.player.setScale(perspectiveScale);
    this.player.setPosition(px,py+3).setDepth(py);

    // Grounded shadow: offset away from nearest light instead of a generic centered blob.
    const near=this.nearestLight(px,py);
    const dx=px-near.config.x,dy=py-near.config.y,n=Math.hypot(dx,dy)||1;
    const strength=Math.max(0,1-near.dist/near.config.radius);
    this.shadow.setPosition(px+(dx/n)*8*strength,py+5+(dy/n)*2*strength);
    this.shadow.setScale(1+.18*strength,.78-.12*strength).setAlpha(.26+.16*strength).setDepth(py-.5);

    // Subtle light flicker from street lamps / windows.
    for(let i=0;i<this.lightObjects.length;i++){
      const o=this.lightObjects[i];
      if(o.config.id==='sky') continue;
      o.light.intensity=o.config.intensity*(.965+.035*Math.sin(time*.0027+i*1.7));
    }

    this.drawWetReflections(time);
    this.drawRain(dt);

    // Small lab interaction: A temporarily reveals the collision-debug view.
    const actionPressed=input.action || this.keys.E?.isDown || this.keys.SPACE?.isDown || this.keys.ENTER?.isDown;
    if(actionPressed && !this.actionLatch){
      this.actionLatch=true;
      document.getElementById('status').textContent='escala · profundidade Y · normal-map shading · Matter collisions';
    }
    if(!actionPressed)this.actionLatch=false;
    input.action=false;
  }

  drawWetReflections(time){
    const g=this.reflectionGfx;g.clear();
    const pulse=.85+.15*Math.sin(time*.0017);
    const streaks=[
      [450,610,18,105,0xf7aa66,.10],[585,635,18,130,0xffb96e,.11],[805,650,22,145,0xf5a35c,.13],[1115,665,18,125,0xffc474,.10]
    ];
    for(const [x,y,w,h,c,a] of streaks){
      g.fillStyle(c,a*pulse);g.fillEllipse(x,y,w,h);
      g.fillStyle(c,a*.45*pulse);g.fillEllipse(x+11,y+18,w*.45,h*.6);
    }
  }

  drawRain(dt){
    const g=this.rainGfx;g.clear();g.lineStyle(1,0xcfd6ef,.16);
    for(const r of this.rain){
      r.x+=r.drift*dt;r.y+=r.speed*dt;
      if(r.y>1086||r.x<0){r.y=-20;r.x=(r.x+1448+((r.y*13)%330))%1448}
      g.lineStyle(1,0xd8ddf2,r.alpha);g.lineBetween(r.x,r.y,r.x-3,r.y+r.len);
    }
  }
}

const config={
  type:Phaser.WEBGL,
  parent:'game',
  backgroundColor:'#0e0d19',
  width:window.innerWidth,
  height:window.innerHeight,
  scene:[StreetLab],
  pixelArt:true,
  antialias:false,
  roundPixels:true,
  render:{pixelArt:true,antialias:false,roundPixels:true,selfShadow:QUALITY==='high'},
  physics:{
    default:'matter',
    matter:{gravity:{x:0,y:0},debug:DEBUG,enableSleeping:false}
  },
  scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},
  maxLights:8
};

new Phaser.Game(config);
})();
