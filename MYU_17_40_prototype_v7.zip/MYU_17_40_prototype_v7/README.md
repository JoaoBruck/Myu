# MYU — 17:40 Prototype v7

Melhorias desta versão:
- sprite ligeiramente menor e mais integrado ao cenário;
- sombra sob os pés;
- offsets por frame para reduzir pequenos pulos;
- câmera mais afastada com dead zone;
- movimento mais fluido, com aceleração/desaceleração melhores;
- velocidade da animação ligada à velocidade real do movimento;
- analógico com curva para andar devagar;
- HUD temporário, menos intrusivo;
- botão A contextual;
- transição de porta mais curta;
- oclusão suavizada.

Obs.: nesta sessão a publicação automática no GitHub não está disponível, então a build está pronta localmente para upload/publicação.
