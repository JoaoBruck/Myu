
const canvas=document.getElementById('game');
const ctx=canvas.getContext('2d',{alpha:false});
ctx.imageSmoothingEnabled=false;
const hud=document.getElementById('hud');
const pill=document.getElementById('pill');
const actionBtn=document.getElementById('actionBtn');

let data,current='exterior',mask,last=0,fade=0,transition=null,hudTimer=0;
const assets={},masks={};
const player={x:0,y:0,vx:0,vy:0,r:12,dir:'front',moving:false,walkCycle:0,stepPhase:0};
const cam={x:0,y:0,zoom:1};
const input={x:0,y:0},keys={};
const DPR=()=>Math.max(1,devicePixelRatio||1);
const frameOffsets={
  front:[[-1,0],[0,-1],[1,0],[0,0]],
  back:[[0,0],[0,-1],[0,0],[0,1]],
  left:[[0,0],[-1,0],[0,-1],[1,0]],
  right:[[0,0],[1,0],[0,-1],[-1,0]],
};

async function loadImage(src){
  if(assets[src]) return assets[src];
  const img=new Image();
  await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;img.src=src});
  assets[src]=img; return img;
}
function scene(){ return data.scenes[current]; }
function statusText(){ return current==='exterior' ? 'Ande pela calçada. A perto da porta entra no café.' : 'Explore o café. A perto da porta volta para a rua.'; }
function showHUD(text, hold=1.6){ pill.textContent=text; hud.classList.remove('hidden'); hudTimer=hold; }

async function boot(){
  data=await fetch('data/scene.json').then(r=>r.json());
  const files=new Set([data.atlas.file]);
  for(const s of Object.values(data.scenes)){ files.add(s.bg); files.add(s.collision); }
  await Promise.all([...files].map(loadImage));
  switchScene('exterior',scene().start.x,scene().start.y,true);
  resize();
  showHUD(statusText(), 3.0);
  requestAnimationFrame(loop);
}
function buildMask(src){
  const img=assets[src],c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
  const x=c.getContext('2d'); x.drawImage(img,0,0);
  return {w:c.width,h:c.height,p:x.getImageData(0,0,c.width,c.height).data};
}
function getMask(src){ return masks[src] || (masks[src]=buildMask(src)); }
function switchScene(name,x,y,instant=false){
  current=name; player.x=x; player.y=y; player.vx=0; player.vy=0; player.walkCycle=0;
  player.dir = current==='exterior' ? 'front' : 'right';
  mask=getMask(scene().collision);
  if(instant){ cam.x=x; cam.y=y; }
  showHUD(statusText(), 1.8);
}
function resize(){
  canvas.width=Math.floor(innerWidth*DPR()); canvas.height=Math.floor(innerHeight*DPR());
  canvas.style.width=innerWidth+'px'; canvas.style.height=innerHeight+'px';
  ctx.imageSmoothingEnabled=false;
  if(data){
    const bg=assets[scene().bg];
    const fit=Math.max(canvas.width/bg.width, canvas.height/bg.height);
    cam.zoom=fit*0.86;
  }
  refreshStick();
}
addEventListener('resize', resize);
function walkable(x,y){
  if(!mask) return false;
  const r=player.r, pts=[[0,0],[r,0],[-r,0],[0,r],[0,-r],[r*.55,r*.55],[-r*.55,r*.55],[r*.55,-r*.55],[-r*.55,-r*.55]];
  for(const [ox,oy] of pts){
    const px=Math.round(x+ox), py=Math.round(y+oy);
    if(px<0||py<0||px>=mask.w||py>=mask.h) return false;
    const i=(py*mask.w+px)*4;
    if(mask.p[i] < 128) return false;
  }
  return true;
}
addEventListener('keydown',e=>{ const k=e.key.toLowerCase(); keys[k]=true; if(['e',' ','enter'].includes(k)){ e.preventDefault(); interact(); } });
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
function axis(){
  let x=input.x, y=input.y;
  const kx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0), ky=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
  if(kx||ky){ x=kx; y=ky; }
  let n=Math.hypot(x,y);
  if(n>1){ x/=n; y/=n; n=1; }
  // Analog deadzone and curve for finer slow movement.
  if(!(kx||ky)){
    const dz=.18;
    if(n<dz){ x=0; y=0; n=0; }
    else { const t=(n-dz)/(1-dz); const curved=t*t*(3-2*t); x=(x/n)*curved; y=(y/n)*curved; }
  }
  return {x,y};
}
const stickZone=document.getElementById('stickZone'), stickBase=document.getElementById('stickBase'), knob=document.getElementById('stickKnob');
let dragging=false, center={x:0,y:0}, radius=1;
function refreshStick(){ const r=stickBase.getBoundingClientRect(); center={x:r.left+r.width/2,y:r.top+r.height/2}; radius=r.width*.36; }
function setStick(x,y){ const dx=x-center.x, dy=y-center.y, n=Math.hypot(dx,dy)||1, m=Math.min(n,radius), mx=dx/n*m, my=dy/n*m; input.x=mx/radius; input.y=my/radius; knob.style.left=`calc(29% + ${mx}px)`; knob.style.top=`calc(29% + ${my}px)`; }
function clearStick(){ dragging=false; input.x=input.y=0; knob.style.left='29%'; knob.style.top='29%'; }
stickZone.addEventListener('pointerdown',e=>{ refreshStick(); dragging=true; setStick(e.clientX,e.clientY); e.preventDefault(); });
addEventListener('pointermove',e=> dragging && setStick(e.clientX,e.clientY));
addEventListener('pointerup',()=> dragging && clearStick());
addEventListener('pointercancel',()=> dragging && clearStick());
actionBtn.addEventListener('pointerdown',()=>{ navigator.vibrate?.(10); interact(); });
function nearDoor(){ const d=scene().door, cx=d.x+d.w/2, cy=d.y+d.h/2; return Math.hypot(player.x-cx, player.y-cy) < 110; }
function interact(){
  if(transition) return;
  if(nearDoor()){
    const d=scene().door;
    transition={to:d.to, spawn:d.spawn, phase:'out'};
    return;
  }
  showHUD('A ação funciona junto à porta.', 1.0);
}
function update(dt){
  if(hudTimer>0){ hudTimer-=dt; if(hudTimer<=0) hud.classList.add('hidden'); }
  actionBtn.classList.toggle('near', nearDoor());
  if(transition){
    const speed=6.5;
    if(transition.phase==='out'){
      fade=Math.min(1, fade+dt*speed);
      player.vx*=0.75; player.vy*=0.75;
      if(fade>=1){ switchScene(transition.to, transition.spawn.x, transition.spawn.y); transition.phase='in'; }
    } else {
      fade=Math.max(0, fade-dt*speed);
      if(fade<=0) transition=null;
    }
  }
  const a=axis();
  const max=current==='exterior'?168:154;
  const targetVx=transition?0:a.x*max, targetVy=transition?0:a.y*max;
  const responsiveness = (Math.abs(a.x)+Math.abs(a.y)>0.01) ? 9.5 : 7.0;
  player.vx += (targetVx-player.vx)*Math.min(1, dt*responsiveness);
  player.vy += (targetVy-player.vy)*Math.min(1, dt*responsiveness);
  const sp=Math.hypot(player.vx, player.vy);
  player.moving=sp>4;
  if(player.moving){
    if(Math.abs(player.vx)>Math.abs(player.vy)) player.dir=player.vx>0?'right':'left';
    else player.dir=player.vy>0?'front':'back';
    const animRate = 2.2 + (sp/max)*4.8;
    player.walkCycle = (player.walkCycle + dt*animRate) % data.atlas.frames;
  } else {
    player.walkCycle = 0;
  }
  let nx=player.x+player.vx*dt, ny=player.y+player.vy*dt;
  if(walkable(nx,player.y)) player.x=nx; else player.vx=0;
  if(walkable(player.x,ny)) player.y=ny; else player.vy=0;
  // camera dead zone
  const bg=assets[scene().bg], vw=canvas.width/cam.zoom, vh=canvas.height/cam.zoom;
  const dx=player.x-cam.x, dy=player.y-cam.y;
  const dzx=vw*0.10, dzy=vh*0.08;
  let targetX=cam.x, targetY=cam.y;
  if(dx>dzx) targetX=player.x-dzx; else if(dx<-dzx) targetX=player.x+dzx;
  if(dy>dzy) targetY=player.y-dzy; else if(dy<-dzy) targetY=player.y+dzy;
  const minX=vw/2, maxX=bg.width-vw/2, minY=vh/2, maxY=bg.height-vh/2;
  targetX=Math.max(minX, Math.min(maxX, targetX)); targetY=Math.max(minY, Math.min(maxY, targetY));
  cam.x += (targetX-cam.x)*Math.min(1, dt*5.2);
  cam.y += (targetY-cam.y)*Math.min(1, dt*5.2);
}
function drawCrop(bg,o){ ctx.drawImage(bg,o.x,o.y,o.w,o.h,o.x,o.y,o.w,o.h); }
function draw(){
  const s=scene(), bg=assets[s.bg];
  ctx.fillStyle='#120f1f'; ctx.fillRect(0,0,canvas.width,canvas.height);
  const vw=canvas.width/cam.zoom, vh=canvas.height/cam.zoom;
  const cx=Math.max(vw/2,Math.min(bg.width-vw/2,cam.x)), cy=Math.max(vh/2,Math.min(bg.height-vh/2,cam.y));
  const sx=cx-vw/2, sy=cy-vh/2;
  ctx.save();
  ctx.scale(cam.zoom, cam.zoom); ctx.translate(-sx,-sy);
  ctx.drawImage(bg,0,0);
  const atlas=assets[data.atlas.file], row=data.atlas.rows[player.dir], fw=data.atlas.frameW, fh=data.atlas.frameH;
  const frame=player.moving?Math.floor(player.walkCycle)%data.atlas.frames:0;
  const depth=current==='exterior'?1.0+(player.y/bg.height)*.11:0.98+(player.y/bg.height)*.07;
  const scale=(data.atlas.scale||1)*depth, dw=fw*scale, dh=fh*scale;
  const off=frameOffsets[player.dir][frame]||[0,0];
  const px=player.x-dw/2+off[0], py=player.y-dh+8+off[1];
  // Shadow under feet
  const shadowY=player.y-6, shadowW=26*depth, shadowH=8*depth;
  ctx.fillStyle='rgba(20,14,33,0.22)';
  ctx.beginPath(); ctx.ellipse(player.x, shadowY, shadowW, shadowH, 0, 0, Math.PI*2); ctx.fill();
  ctx.drawImage(atlas, frame*fw, row*fh, fw, fh, px, py, dw, dh);
  const occ=[...(s.occluders||[])].sort((a,b)=>a.baseline-b.baseline);
  const feetX=player.x, feetY=player.y;
  for(const o of occ){
    const xOverlap = feetX > (o.x - 10) && feetX < (o.x + o.w + 10);
    const yOverlap = feetY < o.baseline && feetY > (o.baseline - 90);
    if(xOverlap && yOverlap) drawCrop(bg,o);
  }
  if(s.staticForeground) drawCrop(bg,s.staticForeground);
  ctx.restore();
  if(fade>0){ ctx.fillStyle=`rgba(9,7,16,${fade})`; ctx.fillRect(0,0,canvas.width,canvas.height); }
}
function loop(t){ if(!last) last=t; const dt=Math.min(.033,(t-last)/1000); last=t; update(dt); draw(); requestAnimationFrame(loop); }
boot();
