const CACHE='myu-1740-v5';
const ASSETS=['./','./index.html','./style.css','./game.js','./manifest.webmanifest','./data/scene.json','./data/exterior_collision.png','./data/interior_collision.png','./assets/backgrounds/exterior.webp','./assets/backgrounds/interior.webp','./assets/sprites/witch_walk_atlas.webp'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)))});
