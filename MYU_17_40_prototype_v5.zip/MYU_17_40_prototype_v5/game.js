const canvas=document.getElementById('game');
const ctx=canvas.getContext('2d',{alpha:false});
ctx.imageSmoothingEnabled=false;
const pill=document.getElementById('pill');
const actionBtn=document.getElementById('actionBtn');
let data,current='exterior',mask,last=0,fade=0,transition=null;
const assets={},masks={};
const player={x:0,y:0,vx:0,vy:0,r:14,dir:'front',moving:false,walkTime:0};
const cam={x:0,y:0,zoom:1};
const input={x:0,y:0},keys={};
const dpr=()=>Math.max(1,devicePixelRatio||1);
async function loadImage(src){if(assets[src])return assets[src];const img=new Image();await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;img.src=src});return assets[src]=img}
function scene(){return data.scenes[current]}
function statusText(){return current==='exterior'?'Ande pela calçada. A perto da porta entra no café.':'Explore o café. A perto da porta volta para a rua.'}
async function boot(){data=await fetch('data/scene.json').then(r=>r.json());const files=new Set([data.atlas.file]);for(const s of Object.values(data.scenes)){files.add(s.bg);files.add(s.collision)}await Promise.all([...files].map(loadImage));switchScene('exterior',scene().start.x,scene().start.y,true);resize();pill.textContent=statusText();requestAnimationFrame(loop)}
function buildMask(src){const img=assets[src],c=document.createElement('canvas');c.width=img.width;c.height=img.height;const x=c.getContext('2d');x.drawImage(img,0,0);return{w:c.width,h:c.height,p:x.getImageData(0,0,c.width,c.height).data}}
function getMask(src){return masks[src]||(masks[src]=buildMask(src))}
function switchScene(name,x,y,instant=false){current=name;player.x=x;player.y=y;player.vx=player.vy=0;mask=getMask(scene().collision);cam.x=x;cam.y=y;if(data)pill.textContent=statusText()}
function resize(){canvas.width=Math.floor(innerWidth*dpr());canvas.height=Math.floor(innerHeight*dpr());canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';ctx.imageSmoothingEnabled=false;if(data){const bg=assets[scene().bg];cam.zoom=Math.max(canvas.width/bg.width,canvas.height/bg.height)*1.08}refreshStick()}
addEventListener('resize',resize);
function walkable(x,y){if(!mask)return false;const r=player.r,pts=[[0,0],[r,0],[-r,0],[0,r],[0,-r],[r*.65,r*.65],[-r*.65,r*.65],[r*.65,-r*.65],[-r*.65,-r*.65]];for(const[ox,oy]of pts){const px=Math.round(x+ox),py=Math.round(y+oy);if(px<0||py<0||px>=mask.w||py>=mask.h)return false;const i=(py*mask.w+px)*4;if(mask.p[i]<128)return false}return true}
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(['e',' ','enter'].includes(e.key.toLowerCase())){e.preventDefault();interact()}});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
function axis(){let x=input.x,y=input.y;const kx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),ky=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);if(kx||ky){x=kx;y=ky}const n=Math.hypot(x,y);if(n>1){x/=n;y/=n}return{x,y}}
const stickZone=document.getElementById('stickZone'),stickBase=document.getElementById('stickBase'),knob=document.getElementById('stickKnob');let dragging=false,center={x:0,y:0},radius=1;
function refreshStick(){const r=stickBase.getBoundingClientRect();center={x:r.left+r.width/2,y:r.top+r.height/2};radius=r.width*.36}
function setStick(x,y){const dx=x-center.x,dy=y-center.y,n=Math.hypot(dx,dy)||1,m=Math.min(n,radius),mx=dx/n*m,my=dy/n*m;input.x=mx/radius;input.y=my/radius;knob.style.left=`calc(29% + ${mx}px)`;knob.style.top=`calc(29% + ${my}px)`}
function clearStick(){dragging=false;input.x=input.y=0;knob.style.left='29%';knob.style.top='29%'}
stickZone.addEventListener('pointerdown',e=>{refreshStick();dragging=true;setStick(e.clientX,e.clientY);e.preventDefault()});addEventListener('pointermove',e=>dragging&&setStick(e.clientX,e.clientY));addEventListener('pointerup',()=>dragging&&clearStick());addEventListener('pointercancel',()=>dragging&&clearStick());actionBtn.addEventListener('pointerdown',()=>{navigator.vibrate?.(15);interact()});
function interact(){if(transition)return;const d=scene().door,cx=d.x+d.w/2,cy=d.y+d.h/2;if(Math.hypot(player.x-cx,player.y-cy)<95){transition={to:d.to,spawn:d.spawn,phase:'out'};return}pill.textContent='A ação funciona junto à porta.';setTimeout(()=>pill.textContent=statusText(),900)}
function update(dt){if(transition){if(transition.phase==='out'){fade=Math.min(1,fade+dt*3.3);if(fade>=1){switchScene(transition.to,transition.spawn.x,transition.spawn.y);transition.phase='in'}}else{fade=Math.max(0,fade-dt*3.3);if(fade<=0)transition=null}}const a=axis(),acc=620,drag=11,max=current==='exterior'?188:168;if(Math.abs(a.x)+Math.abs(a.y)>.03){player.vx+=a.x*acc*dt;player.vy+=a.y*acc*dt}else{player.vx*=Math.max(0,1-drag*dt);player.vy*=Math.max(0,1-drag*dt)}let sp=Math.hypot(player.vx,player.vy);if(sp>max){player.vx=player.vx/sp*max;player.vy=player.vy/sp*max;sp=max}player.moving=sp>9;if(player.moving){if(Math.abs(player.vx)>Math.abs(player.vy))player.dir=player.vx>0?'right':'left';else player.dir=player.vy>0?'front':'back';player.walkTime+=dt}else player.walkTime=0;const nx=player.x+player.vx*dt,ny=player.y+player.vy*dt;if(walkable(nx,player.y))player.x=nx;else player.vx=0;if(walkable(player.x,ny))player.y=ny;else player.vy=0;cam.x+=(player.x-cam.x)*Math.min(1,dt*6);cam.y+=(player.y-cam.y)*Math.min(1,dt*6)}
function redrawCrop(bg,o){ctx.drawImage(bg,o.x,o.y,o.w,o.h,o.x,o.y,o.w,o.h)}
function draw(){const s=scene(),bg=assets[s.bg];ctx.fillStyle='#120f1f';ctx.fillRect(0,0,canvas.width,canvas.height);const vw=canvas.width/cam.zoom,vh=canvas.height/cam.zoom,cx=Math.max(vw/2,Math.min(bg.width-vw/2,cam.x)),cy=Math.max(vh/2,Math.min(bg.height-vh/2,cam.y)),sx=cx-vw/2,sy=cy-vh/2;ctx.save();ctx.scale(cam.zoom,cam.zoom);ctx.translate(-sx,-sy);ctx.drawImage(bg,0,0);const atlas=assets[data.atlas.file],row=data.atlas.rows[player.dir],fw=data.atlas.frameW,fh=data.atlas.frameH,frame=player.moving?Math.floor(player.walkTime*data.atlas.fps)%data.atlas.frames:0,depth=current==='exterior'?1.10+(player.y/bg.height)*.15:1.05+(player.y/bg.height)*.10,scale=(data.atlas.scale||1)*depth,dw=fw*scale,dh=fh*scale,px=player.x-dw/2,py=player.y-dh+8;ctx.drawImage(atlas,frame*fw,row*fh,fw,fh,px,py,dw,dh);const occ=[...(s.occluders||[])].sort((a,b)=>a.baseline-b.baseline);for(const o of occ)if(player.y<o.baseline)redrawCrop(bg,o);if(s.staticForeground)redrawCrop(bg,s.staticForeground);const d=s.door,cxd=d.x+d.w/2,cyd=d.y+d.h/2;if(Math.hypot(player.x-cxd,player.y-cyd)<110){ctx.strokeStyle='rgba(255,235,178,.7)';ctx.lineWidth=2/cam.zoom;ctx.strokeRect(d.x,d.y,d.w,d.h)}ctx.restore();if(fade>0){ctx.fillStyle=`rgba(9,7,16,${fade})`;ctx.fillRect(0,0,canvas.width,canvas.height)}}
function loop(t){if(!last)last=t;const dt=Math.min(.033,(t-last)/1000);last=t;update(dt);draw();requestAnimationFrame(loop)}
boot();
