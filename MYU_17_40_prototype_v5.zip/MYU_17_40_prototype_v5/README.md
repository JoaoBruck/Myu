# MYU — 17:40 HD prototype v5

Vertical slice mobile-first usando o cenário HD escolhido para Myu.

- cenário externo HD e interior da cafeteria;
- sprite da Bruxa redesenhado como sprite 2D nativo, 4 direções × 4 frames;
- aceleração, desaceleração e colisão por máscara;
- oclusão por profundidade (postes, placa, banco, balcão etc. passam à frente da personagem);
- transição externa ↔ cafeteria;
- analógico virtual e botão A no celular; WASD/setas + E/Espaço/Enter no desktop;
- assets WebP para carregamento mais leve no GitHub Pages.

O atlas HD original está preservado no Google Drive do projeto. Esta build usa uma versão WebP de alta qualidade para a web.
