# MYU — 17:40 Prototype v9

Revisão antes do teste:

- removidos os recortes de oclusão que cortavam a personagem;
- colisões refeitas como máscaras contínuas de chão, em vez de retângulos enormes;
- exterior e interior têm agora uma área caminhável principal conectada;
- caminho da posição inicial até a porta foi validado nos dois cenários;
- colisões passam a focar nos pés, reduzindo paredes invisíveis;
- caminhada mantém sequência ping-pong, idle breathing, bob, lean e turn pulse;
- service worker atualizado para v9 com limpeza de caches antigos;
- CSS/JS recebem cache-busting de versão.

Validações locais executadas:
- `node --check game.js` sem erro;
- assets e arquivos obrigatórios presentes;
- spawn exterior e interior estão em área válida;
- porta é alcançável a partir do spawn nos dois mapas;
- exterior tem um único componente caminhável principal; interior tem um componente principal conectado (e uma pequena ilha visual irrelevante fora da rota).
