const CACHE='myu-v9-live';
const CORE=['./','./index.html','./style.css','./game.js','./manifest.webmanifest','./data/scene.json','./data/exterior_collision.png','./data/interior_collision.png','./assets/backgrounds/exterior.webp','./assets/backgrounds/interior.webp','./assets/sprites/witch_walk_atlas.webp'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  event.respondWith((async()=>{
    try{
      const fresh=await fetch(event.request,{cache:'no-store'});
      const copy=fresh.clone();
      caches.open(CACHE).then(c=>c.put(event.request,copy));
      return fresh;
    }catch(err){
      return (await caches.match(event.request)) || caches.match('./index.html');
    }
  })());
});
