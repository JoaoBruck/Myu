
const canvas=document.getElementById('game');
const ctx=canvas.getContext('2d',{alpha:false});
ctx.imageSmoothingEnabled=false;
const hud=document.getElementById('hud');
const pill=document.getElementById('pill');
const actionBtn=document.getElementById('actionBtn');

let data,current='exterior',mask,last=0,fade=0,transition=null,hudTimer=0,globalTime=0;
const assets={},masks={};
const WALK_SEQ=[0,1,2,3,2,1];
const player={
  x:0,y:0,vx:0,vy:0,r:10,dir:'front',moving:false,
  animClock:0,idleClock:0,lastDir:'front',turnPulse:0
};
const cam={x:0,y:0,zoom:1};
const input={x:0,y:0},keys={};
const DPR=()=>Math.max(1,devicePixelRatio||1);
const frameOffsets={
  front:[[-1,0],[0,-1],[1,0],[0,0]],
  back:[[0,0],[0,-1],[0,0],[0,1]],
  left:[[0,0],[-1,0],[0,-1],[1,0]],
  right:[[0,0],[1,0],[0,-1],[-1,0]],
};

async function loadImage(src){ if(assets[src]) return assets[src]; const img=new Image(); await new Promise((res,rej)=>{img.onload=res;img.onerror=rej;img.src=src}); return assets[src]=img; }
function scene(){ return data.scenes[current]; }
function statusText(){ return current==='exterior' ? 'Ande pela calçada. A perto da porta entra no café.' : 'Explore o café. A perto da porta volta para a rua.'; }
function showHUD(text,hold=1.6){ pill.textContent=text; hud.classList.remove('hidden'); hudTimer=hold; }

async function boot(){
  data=await fetch('data/scene.json').then(r=>r.json());
  const files=new Set([data.atlas.file]);
  for(const s of Object.values(data.scenes)){ files.add(s.bg); files.add(s.collision); }
  await Promise.all([...files].map(loadImage));
  switchScene('exterior',scene().start.x,scene().start.y,true);
  resize(); showHUD(statusText(),2.5); requestAnimationFrame(loop);
}
function buildMask(src){ const img=assets[src],c=document.createElement('canvas'); c.width=img.width;c.height=img.height; const x=c.getContext('2d'); x.drawImage(img,0,0); return {w:c.width,h:c.height,p:x.getImageData(0,0,c.width,c.height).data}; }
function getMask(src){ return masks[src] || (masks[src]=buildMask(src)); }
function switchScene(name,x,y,instant=false){ current=name; player.x=x; player.y=y; player.vx=0; player.vy=0; player.animClock=0; player.idleClock=0; player.lastDir=current==='exterior'?'front':'right'; player.dir=player.lastDir; player.turnPulse=0; mask=getMask(scene().collision); if(instant){cam.x=x;cam.y=y} showHUD(statusText(),1.4); }
function resize(){ canvas.width=Math.floor(innerWidth*DPR()); canvas.height=Math.floor(innerHeight*DPR()); canvas.style.width=innerWidth+'px'; canvas.style.height=innerHeight+'px'; ctx.imageSmoothingEnabled=false; if(data){ const bg=assets[scene().bg]; const fit=Math.max(canvas.width/bg.width,canvas.height/bg.height); cam.zoom=fit*0.86; } refreshStick(); }
addEventListener('resize',resize);

function blockedByRects(x,y){
  const blocks=scene().blockers||[];
  for(const b of blocks){
    if(b.type==='rect'){
      if(x>=b.x && x<=b.x+b.w && y>=b.y && y<=b.y+b.h) return true;
    }else if(b.type==='circle'){
      const dx=x-b.x,dy=y-b.y; if(dx*dx+dy*dy<=b.r*b.r) return true;
    }
  }
  return false;
}
function walkable(x,y){
  if(!mask || blockedByRects(x,y)) return false;
  // feet-focused collider
  const pts=[[0,0],[6,0],[-6,0],[0,5],[0,-5],[4,4],[-4,4],[4,-4],[-4,-4]];
  for(const [ox,oy] of pts){
    const px=Math.round(x+ox), py=Math.round(y+oy);
    if(px<0||py<0||px>=mask.w||py>=mask.h) return false;
    const i=(py*mask.w+px)*4; if(mask.p[i] < 128) return false;
  }
  return true;
}

addEventListener('keydown',e=>{ const k=e.key.toLowerCase(); keys[k]=true; if(['e',' ','enter'].includes(k)){ e.preventDefault(); interact(); } });
addEventListener('keyup',e=> keys[e.key.toLowerCase()]=false);
function axis(){
  let x=input.x, y=input.y; const kx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0), ky=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
  if(kx||ky){ x=kx; y=ky; }
  let n=Math.hypot(x,y); if(n>1){ x/=n; y/=n; n=1; }
  if(!(kx||ky)){
    const dz=.20; if(n<dz){ x=0; y=0; n=0; }
    else { const t=(n-dz)/(1-dz); const curved=t*t*(3-2*t); x=(x/n)*curved; y=(y/n)*curved; }
  }
  return {x,y};
}

const stickZone=document.getElementById('stickZone'), stickBase=document.getElementById('stickBase'), knob=document.getElementById('stickKnob');
let dragging=false, center={x:0,y:0}, radius=1;
function refreshStick(){ const r=stickBase.getBoundingClientRect(); center={x:r.left+r.width/2,y:r.top+r.height/2}; radius=r.width*.36; }
function setStick(x,y){ const dx=x-center.x,dy=y-center.y,n=Math.hypot(dx,dy)||1,m=Math.min(n,radius),mx=dx/n*m,my=dy/n*m; input.x=mx/radius; input.y=my/radius; knob.style.left=`calc(29% + ${mx}px)`; knob.style.top=`calc(29% + ${my}px)`; }
function clearStick(){ dragging=false; input.x=input.y=0; knob.style.left='29%'; knob.style.top='29%'; }
stickZone.addEventListener('pointerdown',e=>{ refreshStick(); dragging=true; setStick(e.clientX,e.clientY); e.preventDefault(); });
addEventListener('pointermove',e=> dragging && setStick(e.clientX,e.clientY)); addEventListener('pointerup',()=> dragging && clearStick()); addEventListener('pointercancel',()=> dragging && clearStick());
actionBtn.addEventListener('pointerdown',()=>{ navigator.vibrate?.(10); interact(); });
function nearDoor(){ const d=scene().door, cx=d.x+d.w/2, cy=d.y+d.h/2; return Math.hypot(player.x-cx, player.y-cy) < 95; }
function interact(){ if(transition) return; if(nearDoor()){ const d=scene().door; transition={to:d.to, spawn:d.spawn, phase:'out'}; return; } showHUD('A ação funciona junto à porta.', 1.0); }

function update(dt){
  globalTime += dt;
  if(hudTimer>0){ hudTimer-=dt; if(hudTimer<=0) hud.classList.add('hidden'); }
  actionBtn.classList.toggle('near', nearDoor());
  if(transition){ const speed=7.5; if(transition.phase==='out'){ fade=Math.min(1,fade+dt*speed); player.vx*=0.72; player.vy*=0.72; if(fade>=1){ switchScene(transition.to,transition.spawn.x,transition.spawn.y); transition.phase='in'; } } else { fade=Math.max(0,fade-dt*speed); if(fade<=0) transition=null; } }

  const a=axis(); const max=current==='exterior'?164:150; const targetVx=transition?0:a.x*max, targetVy=transition?0:a.y*max;
  const movingInput=(Math.abs(a.x)+Math.abs(a.y)>0.01);
  player.vx += (targetVx-player.vx)*Math.min(1, dt*(movingInput?10.5:7.5));
  player.vy += (targetVy-player.vy)*Math.min(1, dt*(movingInput?10.5:7.5));
  const sp=Math.hypot(player.vx,player.vy); player.moving=sp>4;

  if(player.moving){
    const newDir = Math.abs(player.vx)>Math.abs(player.vy) ? (player.vx>0?'right':'left') : (player.vy>0?'front':'back');
    if(newDir!==player.dir){ player.lastDir=player.dir; player.dir=newDir; player.turnPulse=0.14; }
    const animRate=2.8+(sp/max)*5.0; player.animClock=(player.animClock+dt*animRate)%WALK_SEQ.length; player.idleClock=0;
  } else {
    player.idleClock += dt; player.animClock=0;
  }
  if(player.turnPulse>0) player.turnPulse=Math.max(0, player.turnPulse-dt);

  let nx=player.x+player.vx*dt, ny=player.y+player.vy*dt;
  if(walkable(nx,player.y)) player.x=nx; else player.vx=0;
  if(walkable(player.x,ny)) player.y=ny; else player.vy=0;

  const bg=assets[scene().bg], vw=canvas.width/cam.zoom, vh=canvas.height/cam.zoom;
  const dx=player.x-cam.x, dy=player.y-cam.y, dzx=vw*0.09, dzy=vh*0.075; let targetX=cam.x,targetY=cam.y;
  if(dx>dzx) targetX=player.x-dzx; else if(dx<-dzx) targetX=player.x+dzx;
  if(dy>dzy) targetY=player.y-dzy; else if(dy<-dzy) targetY=player.y+dzy;
  const minX=vw/2, maxX=bg.width-vw/2, minY=vh/2, maxY=bg.height-vh/2;
  targetX=Math.max(minX, Math.min(maxX, targetX)); targetY=Math.max(minY, Math.min(maxY, targetY));
  cam.x += (targetX-cam.x)*Math.min(1, dt*5.8); cam.y += (targetY-cam.y)*Math.min(1, dt*5.8);
}

function drawCrop(bg,o){ ctx.drawImage(bg,o.x,o.y,o.w,o.h,o.x,o.y,o.w,o.h); }
function draw(){
  const s=scene(), bg=assets[s.bg]; ctx.fillStyle='#120f1f'; ctx.fillRect(0,0,canvas.width,canvas.height);
  const vw=canvas.width/cam.zoom, vh=canvas.height/cam.zoom; const cx=Math.max(vw/2,Math.min(bg.width-vw/2,cam.x)), cy=Math.max(vh/2,Math.min(bg.height-vh/2,cam.y)); const sx=cx-vw/2, sy=cy-vh/2;
  ctx.save(); ctx.scale(cam.zoom,cam.zoom); ctx.translate(-sx,-sy); ctx.drawImage(bg,0,0);
  const atlas=assets[data.atlas.file], row=data.atlas.rows[player.dir], fw=data.atlas.frameW, fh=data.atlas.frameH;
  const frame=player.moving?WALK_SEQ[Math.floor(player.animClock)%WALK_SEQ.length]:0;
  const depth=current==='exterior'?1.0+(player.y/bg.height)*.11:0.98+(player.y/bg.height)*.07;
  const moveSpeed=Math.min(1, Math.hypot(player.vx,player.vy)/(current==='exterior'?164:150));
  const bob=player.moving ? Math.sin(player.animClock/WALK_SEQ.length*Math.PI*2)*3.0*moveSpeed : Math.sin(player.idleClock*2.1)*1.0;
  const breathe=player.moving ? 0 : Math.sin(player.idleClock*2.0)*0.012;
  const stretch=player.moving ? Math.sin(player.animClock/WALK_SEQ.length*Math.PI*2)*0.018*moveSpeed : 0;
  const leanX = Math.max(-3, Math.min(3, player.vx*0.018));
  const turnBump = player.turnPulse>0 ? Math.sin((player.turnPulse/0.14)*Math.PI)*1.6 : 0;
  const scale=(data.atlas.scale||1)*depth, scaleX=scale*(1-breathe-stretch*0.6), scaleY=scale*(1+breathe+stretch);
  const dw=fw*scaleX, dh=fh*scaleY; const off=frameOffsets[player.dir][frame]||[0,0];
  const px=player.x-dw/2+off[0]+leanX, py=player.y-dh+8+off[1]-bob-turnBump;
  const shadowPulse = player.moving ? 1+Math.sin(player.animClock/WALK_SEQ.length*Math.PI*2)*0.07 : 1+Math.sin(player.idleClock*2.0)*0.03;
  ctx.fillStyle='rgba(20,14,33,0.20)'; ctx.beginPath(); ctx.ellipse(player.x, player.y-6, 24*depth*shadowPulse, 7.5*depth/shadowPulse, 0, 0, Math.PI*2); ctx.fill();
  ctx.drawImage(atlas, frame*fw, row*fh, fw, fh, px, py, dw, dh);
  if(s.staticForeground) drawCrop(bg,s.staticForeground);
  ctx.restore();
  if(fade>0){ ctx.fillStyle=`rgba(9,7,16,${fade})`; ctx.fillRect(0,0,canvas.width,canvas.height); }
}
function loop(t){ if(!last) last=t; const dt=Math.min(.033,(t-last)/1000); last=t; update(dt); draw(); requestAnimationFrame(loop); }
boot();
