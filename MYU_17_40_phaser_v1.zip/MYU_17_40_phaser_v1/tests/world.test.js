import fs from 'node:fs';
import { WORLDS, PLAYER } from '../src/data/world.js';

function contains(poly, x, y) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    const intersect = ((yi > y) !== (yj > y)) &&
      (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-9) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function hit(def, x, y, padding = 5) {
  if (def.type === 'circle') {
    return Math.hypot(x - def.x, y - def.y) <= def.r + padding;
  }
  return x + padding > def.x && x - padding < def.x + def.w && y + padding > def.y && y - padding < def.y + def.h;
}

function walkable(world, x, y) {
  const inside = world.walkPolygons.some(poly => contains(poly, x, y));
  if (!inside) return false;
  return !world.colliders.some(c => hit(c, x, y));
}

function nearestWalkable(world, x, y, radius = 120) {
  if (walkable(world, x, y)) return [x, y];
  for (let r = 1; r <= radius; r += 2) {
    for (let dx = -r; dx <= r; dx += 4) {
      for (const dy of [-r, r]) if (walkable(world, x + dx, y + dy)) return [x + dx, y + dy];
    }
    for (let dy = -r; dy <= r; dy += 4) {
      for (const dx of [-r, r]) if (walkable(world, x + dx, y + dy)) return [x + dx, y + dy];
    }
  }
  return null;
}

function pathExists(world, start, target) {
  const step = 12;
  const s = nearestWalkable(world, start.x, start.y);
  const t = nearestWalkable(world, target.x, target.y, target.radius + 80);
  if (!s || !t) return false;
  const key = (x, y) => `${x},${y}`;
  const sx = Math.round(s[0] / step) * step;
  const sy = Math.round(s[1] / step) * step;
  const tx = Math.round(t[0] / step) * step;
  const ty = Math.round(t[1] / step) * step;
  const q = [[sx, sy]];
  const seen = new Set([key(sx, sy)]);
  while (q.length) {
    const [x, y] = q.shift();
    if (Math.hypot(x - tx, y - ty) < 24) return true;
    for (const [dx, dy] of [[step,0],[-step,0],[0,step],[0,-step]]) {
      const nx = x + dx, ny = y + dy;
      const k = key(nx, ny);
      if (!seen.has(k) && walkable(world, nx, ny)) {
        seen.add(k);
        q.push([nx, ny]);
      }
    }
  }
  return false;
}

const tests = [];
const add = (name, fn) => tests.push([name, fn]);

add('1. escala do jogador é compatível com o cenário', () => PLAYER.scale >= 0.28 && PLAYER.scale <= 0.33);
add('2. exterior: spawn e porta têm caminho livre', () => pathExists(WORLDS.exterior, WORLDS.exterior.start, WORLDS.exterior.door));
add('3. interior: spawn e porta têm caminho livre', () => pathExists(WORLDS.interior, WORLDS.interior.start, WORLDS.interior.door));
add('4. interior: corredor central permanece livre', () => {
  const points = [[770,760],[900,720],[1000,650],[820,610]];
  return points.filter(([x,y]) => walkable(WORLDS.interior,x,y)).length >= 3;
});
add('5. objetos críticos possuem colisores pequenos e overlays de profundidade', () => {
  const giant = Object.values(WORLDS).flatMap(w => w.colliders).filter(c => c.type === 'rect' && (c.w > 400 || c.h > 260));
  const allForeground = Object.values(WORLDS).flatMap(w => w.foreground).every(f => fs.existsSync(new URL(`../${f.file}`, import.meta.url)));
  return giant.length === 0 && allForeground;
});

let failed = 0;
for (const [name, fn] of tests) {
  let ok = false;
  try { ok = Boolean(fn()); } catch (error) { console.error(name, error); }
  console.log(`${ok ? 'PASS' : 'FAIL'} — ${name}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
