# MYU — 17:40 Phaser Rebuild v1

Primeiro marco da reconstrução do RPG em **JavaScript + Phaser 3**.

## Objetivo desta build

Validar a base técnica antes de voltar a adicionar NPCs, história, áudio e sistemas maiores.

Esta versão contém somente:
- rua 17:40;
- interior do café;
- personagem jogável;
- animação em 4 direções;
- câmera com dead zone;
- controles mobile e teclado;
- colisões pequenas por objeto;
- regiões caminháveis explícitas;
- profundidade por eixo Y;
- overlays de foreground para postes, placas, mesas, balcão e estante;
- transição rua ↔ café.

O NPC da build anterior foi **deliberadamente removido** deste marco. Primeiro a base precisa ficar correta.

## Estrutura

```text
src/
  main.js
  scenes/
    BootScene.js
    WorldScene.js
  entities/
    Player.js
  systems/
    InputController.js
  data/
    world.js
assets/
  backgrounds/
  sprites/
  foreground/
tests/
  world.test.js
```

## Debug de colisão

Adicione `?debug=1` ao endereço. As áreas caminháveis aparecem em verde, colisores em vermelho e a porta em amarelo.

## Testes

`npm run check` valida a sintaxe dos módulos.

`npm test` executa 5 testes estruturais: escala, caminho até as portas nos dois mapas, corredor interno e verificação de colisores/foreground.

## Phaser

A build carrega Phaser 3.90.0 via jsDelivr. Não há processo de build; é um site estático compatível com GitHub Pages.
