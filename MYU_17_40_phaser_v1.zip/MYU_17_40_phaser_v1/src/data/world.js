export const WORLD_SIZE = { width: 1448, height: 1086 };

export const PLAYER = {
  texture: 'witch',
  frameWidth: 184,
  frameHeight: 316,
  scale: 0.30,
  speed: 168,
  body: { width: 70, height: 40, offsetX: 57, offsetY: 266 }
};

export const WORLDS = {
  exterior: {
    key: 'exterior',
    label: 'Rua — 17:40',
    background: { key: 'bg-exterior', file: 'assets/backgrounds/exterior.webp' },
    start: { x: 470, y: 690, dir: 'right' },
    door: { x: 785, y: 585, radius: 76, target: 'interior', spawn: { x: 165, y: 790, dir: 'back' } },
    walkPolygons: [
      [[0,430],[150,430],[290,475],[530,525],[770,530],[940,505],[1025,445],[1135,425],[1280,470],[1448,560],[1448,750],[1340,765],[1190,735],[1060,710],[900,755],[720,815],[500,830],[310,790],[145,730],[0,650]]
    ],
    colliders: [
      { type:'rect', x:22, y:386, w:145, h:72, debug:'bench' },
      { type:'rect', x:208, y:423, w:112, h:74, debug:'left planter' },
      { type:'rect', x:326, y:430, w:275, h:68, debug:'window planter' },
      { type:'rect', x:625, y:505, w:68, h:72, debug:'chalk board' },
      { type:'circle', x:864, y:514, r:27, debug:'door plant' },
      { type:'circle', x:1118, y:533, r:24, debug:'lamp post' },
      { type:'rect', x:1180, y:523, w:118, h:62, debug:'right planter' },
      { type:'rect', x:1320, y:675, w:34, h:108, debug:'direction sign' },
      { type:'circle', x:39, y:540, r:17, debug:'bollard 1' },
      { type:'circle', x:176, y:592, r:17, debug:'bollard 2' },
      { type:'circle', x:301, y:637, r:17, debug:'bollard 3' },
      { type:'circle', x:449, y:692, r:18, debug:'bollard 4' },
      { type:'circle', x:790, y:738, r:18, debug:'bollard 5' }
    ],
    foreground: [
      { key:'ext_bollard_a', file:'assets/foreground/ext_bollard_a.png', x:8, y:470, baseline:570 },
      { key:'ext_bollard_b', file:'assets/foreground/ext_bollard_b.png', x:140, y:515, baseline:625 },
      { key:'ext_bollard_c', file:'assets/foreground/ext_bollard_c.png', x:265, y:555, baseline:670 },
      { key:'ext_bollard_d', file:'assets/foreground/ext_bollard_d.png', x:405, y:605, baseline:725 },
      { key:'ext_bollard_e', file:'assets/foreground/ext_bollard_e.png', x:745, y:650, baseline:790 },
      { key:'ext_board', file:'assets/foreground/ext_board.png', x:600, y:430, baseline:600 },
      { key:'ext_lamppost', file:'assets/foreground/ext_lamppost.png', x:1045, y:65, baseline:560 },
      { key:'ext_planter_right', file:'assets/foreground/ext_planter_right.png', x:1150, y:455, baseline:630 },
      { key:'ext_direction_sign', file:'assets/foreground/ext_direction_sign.png', x:1215, y:575, baseline:800 }
    ]
  },

  interior: {
    key: 'interior',
    label: 'Café — 17:40',
    background: { key: 'bg-interior', file: 'assets/backgrounds/interior.webp' },
    start: { x: 165, y: 790, dir: 'back' },
    door: { x: 145, y: 790, radius: 78, target: 'exterior', spawn: { x: 770, y: 655, dir: 'front' } },
    walkPolygons: [
      [[82,620],[215,550],[340,520],[470,465],[610,430],[760,430],[910,500],[1200,520],[1365,615],[1390,820],[1270,940],[1010,1010],[720,1025],[440,970],[245,900],[112,830]],
      [[0,710],[115,690],[205,735],[210,900],[130,980],[0,965]]
    ],
    colliders: [
      { type:'rect', x:374, y:423, w:142, h:82, debug:'window table' },
      { type:'rect', x:596, y:342, w:132, h:80, debug:'upper table' },
      { type:'rect', x:683, y:548, w:137, h:82, debug:'center table' },
      { type:'rect', x:489, y:689, w:145, h:90, debug:'lower table' },
      { type:'rect', x:833, y:329, w:357, h:183, debug:'counter' },
      { type:'rect', x:1126, y:683, w:164, h:125, debug:'bookshelf' },
      { type:'circle', x:276, y:737, r:30, debug:'entrance plant' },
      { type:'rect', x:318, y:843, w:360, h:78, debug:'front divider' }
    ],
    foreground: [
      { key:'int_table_window', file:'assets/foreground/int_table_window.png', x:315, y:345, baseline:575 },
      { key:'int_table_upper', file:'assets/foreground/int_table_upper.png', x:535, y:250, baseline:500 },
      { key:'int_table_center', file:'assets/foreground/int_table_center.png', x:625, y:480, baseline:700 },
      { key:'int_table_lower', file:'assets/foreground/int_table_lower.png', x:425, y:610, baseline:855 },
      { key:'int_counter', file:'assets/foreground/int_counter.png', x:790, y:245, baseline:560 },
      { key:'int_bookshelf', file:'assets/foreground/int_bookshelf.png', x:1070, y:605, baseline:880 },
      { key:'int_front_divider', file:'assets/foreground/int_front_divider.png', x:300, y:760, baseline:970 }
    ]
  }
};

export function getWorld(key) {
  return WORLDS[key] || WORLDS.exterior;
}
