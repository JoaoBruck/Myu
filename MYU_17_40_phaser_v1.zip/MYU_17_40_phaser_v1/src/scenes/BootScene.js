import { WORLDS } from '../data/world.js';

export class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  preload() {
    this.load.image(WORLDS.exterior.background.key, WORLDS.exterior.background.file);
    this.load.image(WORLDS.interior.background.key, WORLDS.interior.background.file);
    this.load.spritesheet('witch', 'assets/sprites/witch_walk_atlas.webp', { frameWidth: 184, frameHeight: 316 });
    this.load.spritesheet('shadow', 'assets/sprites/shadow_atlas.png', { frameWidth: 64, frameHeight: 32 });

    const foreground = new Map();
    Object.values(WORLDS).forEach(world => world.foreground.forEach(item => foreground.set(item.key, item.file)));
    foreground.forEach((file, key) => this.load.image(key, file));
  }

  create() {
    const make = (key, row) => {
      const start = row * 4;
      this.anims.create({
        key,
        frames: [start, start + 1, start + 2, start + 3, start + 2, start + 1].map(frame => ({ key: 'witch', frame })),
        frameRate: 8,
        repeat: -1
      });
    };
    make('witch-walk-front', 0);
    make('witch-walk-left', 1);
    make('witch-walk-right', 2);
    make('witch-walk-back', 3);

    this.scene.start('WorldScene', { world: 'exterior' });
  }
}
