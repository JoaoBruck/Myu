import { WORLD_SIZE, getWorld } from '../data/world.js';
import { Player } from '../entities/Player.js';
import { InputController } from '../systems/InputController.js';

export class WorldScene extends Phaser.Scene {
  constructor() {
    super('WorldScene');
    this.worldKey = 'exterior';
    this.worldData = null;
    this.safe = { x: 0, y: 0 };
    this.transitioning = false;
  }

  init(data) {
    this.worldKey = data?.world || 'exterior';
    this.spawn = data?.spawn || null;
  }

  create() {
    this.worldData = getWorld(this.worldKey);
    this.physics.world.setBounds(0, 0, WORLD_SIZE.width, WORLD_SIZE.height);

    this.background = this.add.image(0, 0, this.worldData.background.key)
      .setOrigin(0)
      .setDepth(-100000);

    this.walkPolygons = this.worldData.walkPolygons.map(points => new Phaser.Geom.Polygon(points.map(([x, y]) => ({ x, y }))));

    this.staticColliders = [];
    for (const collider of this.worldData.colliders) this.createCollider(collider);

    for (const fg of this.worldData.foreground) {
      this.add.image(fg.x, fg.y, fg.key)
        .setOrigin(0)
        .setDepth(fg.baseline);
    }

    const start = this.spawn || this.worldData.start;
    this.player = new Player(this, start.x, start.y, start.dir);
    this.safe.x = start.x;
    this.safe.y = start.y;

    for (const collider of this.staticColliders) this.physics.add.collider(this.player, collider);

    this.controls = new InputController(this, () => this.handleAction());
    this.configureCamera();

    if (this.isDebug()) this.drawDebug();

    this.cameras.main.fadeIn(230, 10, 8, 18);
    this.time.delayedCall(80, () => document.body.classList.add('ready'));
  }

  createCollider(def) {
    let zone;
    if (def.type === 'circle') {
      zone = this.add.zone(def.x, def.y, def.r * 2, def.r * 2);
      this.physics.add.existing(zone, true);
      zone.body.setCircle(def.r);
      zone.body.setOffset(0, 0);
      zone.body.updateFromGameObject();
    } else {
      zone = this.add.zone(def.x + def.w / 2, def.y + def.h / 2, def.w, def.h);
      this.physics.add.existing(zone, true);
      zone.body.setSize(def.w, def.h, true);
      zone.body.updateFromGameObject();
    }
    zone.name = def.debug || 'collider';
    this.staticColliders.push(zone);
  }

  configureCamera() {
    const cam = this.cameras.main;
    cam.setBounds(0, 0, WORLD_SIZE.width, WORLD_SIZE.height);
    cam.startFollow(this.player, true, 0.085, 0.085);
    this.applyCameraLayout();
    this.scale.on('resize', () => this.applyCameraLayout());
  }

  applyCameraLayout() {
    const portrait = this.scale.height >= this.scale.width;
    const zoom = portrait ? 0.78 : 0.94;
    const cam = this.cameras.main;
    cam.setZoom(zoom);
    cam.setDeadzone(
      Math.max(90, this.scale.width * (portrait ? 0.18 : 0.22)),
      Math.max(76, this.scale.height * (portrait ? 0.11 : 0.16))
    );
  }

  isInsideWalkArea(x, y) {
    return this.walkPolygons.some(poly => Phaser.Geom.Polygon.Contains(poly, x, y));
  }

  enforceWalkArea() {
    const feetX = this.player.x;
    const feetY = this.player.y - 2;
    if (this.isInsideWalkArea(feetX, feetY)) {
      this.safe.x = this.player.x;
      this.safe.y = this.player.y;
      return;
    }
    this.player.setPosition(this.safe.x, this.safe.y);
    this.player.setVelocity(0, 0);
  }

  nearDoor() {
    const d = this.worldData.door;
    return Phaser.Math.Distance.Between(this.player.x, this.player.y, d.x, d.y) <= d.radius;
  }

  handleAction() {
    if (this.transitioning || !this.nearDoor()) return;
    const d = this.worldData.door;
    this.transitioning = true;
    this.controls.setVisible(false);
    this.player.setVelocity(0, 0);
    this.cameras.main.fadeOut(220, 10, 8, 18);
    this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.restart({ world: d.target, spawn: d.spawn });
    });
  }

  update() {
    this.controls.update();
    if (this.transitioning) {
      this.player.drive({ x: 0, y: 0 });
      this.player.syncPresentation();
      return;
    }

    this.player.drive(this.controls.getVector());
    this.enforceWalkArea();
    this.player.syncPresentation();

    const door = this.nearDoor();
    this.controls.setActionLabel(door ? (this.worldKey === 'exterior' ? 'entrar' : 'sair') : 'agir', door);
  }

  isDebug() {
    return new URLSearchParams(window.location.search).get('debug') === '1';
  }

  drawDebug() {
    const g = this.add.graphics().setDepth(999000);
    g.lineStyle(2, 0x52e390, 0.85);
    for (const poly of this.walkPolygons) g.strokePoints(poly.points, true);

    g.lineStyle(2, 0xff526f, 0.9);
    for (const def of this.worldData.colliders) {
      if (def.type === 'circle') g.strokeCircle(def.x, def.y, def.r);
      else g.strokeRect(def.x, def.y, def.w, def.h);
    }

    const d = this.worldData.door;
    g.lineStyle(2, 0xffe16a, 0.95).strokeCircle(d.x, d.y, d.radius);
  }
}
