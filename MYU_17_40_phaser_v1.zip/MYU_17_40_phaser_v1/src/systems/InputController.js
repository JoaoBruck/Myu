export class InputController {
  constructor(scene, onAction) {
    this.scene = scene;
    this.onAction = onAction;
    this.joyPointer = null;
    this.joyVector = new Phaser.Math.Vector2();
    this.keyboard = scene.input.keyboard.addKeys({
      up: Phaser.Input.Keyboard.KeyCodes.W,
      down: Phaser.Input.Keyboard.KeyCodes.S,
      left: Phaser.Input.Keyboard.KeyCodes.A,
      right: Phaser.Input.Keyboard.KeyCodes.D,
      up2: Phaser.Input.Keyboard.KeyCodes.UP,
      down2: Phaser.Input.Keyboard.KeyCodes.DOWN,
      left2: Phaser.Input.Keyboard.KeyCodes.LEFT,
      right2: Phaser.Input.Keyboard.KeyCodes.RIGHT,
      action: Phaser.Input.Keyboard.KeyCodes.SPACE,
      action2: Phaser.Input.Keyboard.KeyCodes.ENTER,
      action3: Phaser.Input.Keyboard.KeyCodes.E
    });

    this.depth = 1000000;
    this.base = scene.add.circle(0, 0, 70, 0x171529, 0.22)
      .setStrokeStyle(2, 0xffffff, 0.10).setScrollFactor(0).setDepth(this.depth);
    this.knob = scene.add.circle(0, 0, 29, 0xf0ecf7, 0.82)
      .setStrokeStyle(2, 0xffffff, 0.22).setScrollFactor(0).setDepth(this.depth + 1);

    this.action = scene.add.circle(0, 0, 55, 0x655789, 0.48)
      .setStrokeStyle(2, 0xffffff, 0.12).setScrollFactor(0).setDepth(this.depth).setInteractive({ useHandCursor: true });
    this.actionA = scene.add.text(0, 0, 'A', { fontFamily: 'monospace', fontSize: '30px', color: '#ffffff' })
      .setOrigin(0.5).setScrollFactor(0).setDepth(this.depth + 1);
    this.actionLabel = scene.add.text(0, 0, 'agir', { fontFamily: 'monospace', fontSize: '10px', color: '#ded4ea' })
      .setOrigin(0.5).setScrollFactor(0).setDepth(this.depth + 1);

    this.action.on('pointerdown', (pointer, localX, localY, event) => {
      event?.stopPropagation?.();
      this.onAction?.();
      if (navigator.vibrate) navigator.vibrate(8);
    });

    scene.input.on('pointerdown', pointer => {
      if (pointer.x < scene.scale.width * 0.48 && pointer.y > scene.scale.height * 0.55) {
        this.joyPointer = pointer.id;
        this.updateJoystick(pointer);
      }
    });
    scene.input.on('pointermove', pointer => {
      if (pointer.id === this.joyPointer && pointer.isDown) this.updateJoystick(pointer);
    });
    const release = pointer => {
      if (pointer.id === this.joyPointer) {
        this.joyPointer = null;
        this.joyVector.set(0, 0);
        this.knob.setPosition(this.base.x, this.base.y);
      }
    };
    scene.input.on('pointerup', release);
    scene.input.on('pointerupoutside', release);

    this.lastActionDown = false;
    this.layout();
    scene.scale.on('resize', () => this.layout());
  }

  layout() {
    const w = this.scene.scale.width;
    const h = this.scene.scale.height;
    const portrait = h >= w;
    const joyX = portrait ? 88 : 96;
    const joyY = h - (portrait ? 112 : 92);
    const actionX = w - (portrait ? 82 : 92);
    const actionY = h - (portrait ? 108 : 88);

    this.base.setPosition(joyX, joyY).setRadius(portrait ? 66 : 58);
    this.knob.setPosition(joyX, joyY).setRadius(portrait ? 28 : 25);
    this.action.setPosition(actionX, actionY).setRadius(portrait ? 54 : 48);
    this.actionA.setPosition(actionX, actionY - 6).setFontSize(portrait ? 30 : 27);
    this.actionLabel.setPosition(actionX, actionY + 24);
  }

  updateJoystick(pointer) {
    const dx = pointer.x - this.base.x;
    const dy = pointer.y - this.base.y;
    const max = this.base.radius * 0.62;
    const len = Math.hypot(dx, dy) || 1;
    const dist = Math.min(max, len);
    const nx = dx / len;
    const ny = dy / len;
    this.knob.setPosition(this.base.x + nx * dist, this.base.y + ny * dist);
    const strength = dist / max;
    const dead = 0.13;
    const t = strength <= dead ? 0 : (strength - dead) / (1 - dead);
    const curved = t * t * (3 - 2 * t);
    this.joyVector.set(nx * curved, ny * curved);
  }

  getVector() {
    let x = this.joyVector.x;
    let y = this.joyVector.y;
    if (this.keyboard.left.isDown || this.keyboard.left2.isDown) x -= 1;
    if (this.keyboard.right.isDown || this.keyboard.right2.isDown) x += 1;
    if (this.keyboard.up.isDown || this.keyboard.up2.isDown) y -= 1;
    if (this.keyboard.down.isDown || this.keyboard.down2.isDown) y += 1;
    const len = Math.hypot(x, y);
    if (len > 1) { x /= len; y /= len; }
    return { x, y };
  }

  update() {
    const down = this.keyboard.action.isDown || this.keyboard.action2.isDown || this.keyboard.action3.isDown;
    if (down && !this.lastActionDown) this.onAction?.();
    this.lastActionDown = down;
  }

  setActionLabel(label, active = false) {
    this.actionLabel.setText(label);
    this.action.setAlpha(active ? 0.92 : 0.42);
    this.action.setFillStyle(active ? 0x7968a0 : 0x655789, active ? 0.90 : 0.48);
  }

  setVisible(visible) {
    [this.base, this.knob, this.action, this.actionA, this.actionLabel].forEach(x => x.setVisible(visible));
  }
}
