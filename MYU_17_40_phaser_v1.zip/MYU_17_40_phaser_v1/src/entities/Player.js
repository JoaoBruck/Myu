import { PLAYER } from '../data/world.js';

const ANIMS = {
  front: 'witch-walk-front',
  left: 'witch-walk-left',
  right: 'witch-walk-right',
  back: 'witch-walk-back'
};

export class Player extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, dir = 'front') {
    super(scene, x, y, PLAYER.texture, 0);
    scene.add.existing(this);
    scene.physics.add.existing(this);

    this.direction = dir;
    this.speed = PLAYER.speed;
    this.setOrigin(0.5, 1);
    this.setScale(PLAYER.scale);
    this.setCollideWorldBounds(false);
    this.setDepth(y);

    this.body.setSize(PLAYER.body.width, PLAYER.body.height);
    this.body.setOffset(PLAYER.body.offsetX, PLAYER.body.offsetY);
    this.body.setMaxVelocity(this.speed, this.speed);

    this.shadow = scene.add.sprite(x, y - 4, 'shadow', 0)
      .setOrigin(0.5)
      .setScale(0.70, 0.48)
      .setAlpha(0.34)
      .setDepth(y - 1);

    this.face(dir, true);
  }

  face(dir, force = false) {
    if (!force && dir === this.direction) return;
    this.direction = dir;
    const row = { front: 0, left: 1, right: 2, back: 3 }[dir] ?? 0;
    this.setFrame(row * 4);
  }

  drive(vector) {
    const len = Math.hypot(vector.x, vector.y);
    if (len < 0.02) {
      this.setVelocity(0, 0);
      this.anims.stop();
      this.face(this.direction, true);
      return;
    }

    const nx = vector.x / Math.max(1, len);
    const ny = vector.y / Math.max(1, len);
    const magnitude = Math.min(1, len);
    this.setVelocity(nx * this.speed * magnitude, ny * this.speed * magnitude);

    let dir;
    if (Math.abs(nx) > Math.abs(ny)) dir = nx > 0 ? 'right' : 'left';
    else dir = ny > 0 ? 'front' : 'back';
    this.direction = dir;

    const key = ANIMS[dir];
    if (this.anims.currentAnim?.key !== key || !this.anims.isPlaying) this.play(key, true);
    this.anims.timeScale = 0.62 + magnitude * 0.58;
  }

  syncPresentation() {
    const frameIndex = this.anims.currentFrame?.index ?? 0;
    this.shadow.setFrame(Math.max(0, Math.min(3, frameIndex % 4)));
    this.shadow.setPosition(this.x, this.y - 4);
    this.shadow.setDepth(this.y - 1);
    this.setDepth(this.y);
  }

  destroy(fromScene) {
    this.shadow?.destroy();
    super.destroy(fromScene);
  }
}
